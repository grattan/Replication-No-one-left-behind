#==============================================================
# Long run charts
# Project: Full Employment
# Alex Ballantyne, partially borrowed from old Cowgill code
# 12 May 2022

#
# Note: requires historical AWE excel workbook in "data" folder
#

#==============================================================

library(tidyverse)
library(auseconhist) # devtools::install_github("mattcowgill/auseconhist")
library(readabs)  # remotes::install_github("mattcowgill/readabs") when ABS breaks things that need to be fixed
library(readrba)
library(readxl)
library(grattantheme)
library(ggtext)
library(ggrepel)
library(rvest)
library(lubridate)
library(fy)



#=====================================================================
# Control

rm(list=ls())

# Base directory
basepath <- here::here()
setwd(basepath)

# Import utility functions
source("R/utilities.R")


#=====================================================================
# Import data



#---------------------------------------------------------------------
# LR unemp chart (lr_lfs comes from auseconhist package)
lr_ur <- lr_lfs %>%
  select(date, unemp_rate) %>%
  mutate(source = "LR",
         unemp_rate = unemp_rate * 100)

ur <- read_abs(series_id = "A84423050A")

lr_ur <- lr_ur %>%
  filter(date < min(ur$date))

lr_ur <- ur %>%
  select(date, unemp_rate = value) %>%
  mutate(source = "ABS") %>%
  bind_rows(lr_ur) %>%
  mutate(date = floor_date(date, unit = "month")) %>%
  arrange(date)

ur_latest_month <- lr_ur %>%
  filter(date == max(date))


#---------------------------------------------------------------------
# LR interest rates


# Short rate on 90 day bills
lr_yield_bills <- butlin_t6 %>%
  mutate(source = "LR", date = as.Date(ISOdate(year,06,30))) %>%
  select(date, bill_yield, source) %>%
  rename(yield_bills = bill_yield)

# Pull RBA overnight and 3-month bills
short_cashrate <- read_rba(series_id = "FIRMMCRI")
short_yield_bills <- read_rba(series_id = "FIRMMBAB90")

# Cut the historical series when RBA starts
lr_yield_bills <- lr_yield_bills %>%
  filter(date < min(short_yield_bills$date))

# Combine sources
lr_yield_bills <- short_yield_bills %>%
  select(date, yield_bills = value) %>%
  mutate(source = "RBA") %>%
  bind_rows(lr_yield_bills) %>%
  mutate(date = floor_date(date, unit = "month")) %>%
  arrange(date)


#---------------------------------------------------------------------
# Prices, Butlin 1990 = 100

# Pull historical series
lr_cpi_lvl <- butlin_t7 %>%
  mutate(source = "LR", date = as.Date(ISOdate(year,06,30))) %>%
  select(date, cpi, source)

# Make it percentage change, Butlin annual
lr_cpi_ypc <- lr_cpi_lvl %>%
  mutate(cpi_ypc = cpi/dplyr::lag(cpi)*100-100) %>%
  select(date, cpi_ypc, source)

# PULL RBA series for CPI
short_cpi_ypc <- read_rba(series_id = "GCPIAGYP")

# Cut historical series short to when RBA starts
lr_cpi_ypc <- lr_cpi_ypc %>%
  filter(date < min(short_cpi_ypc$date))

# Combine sources
lr_cpi_ypc <- short_cpi_ypc %>%
  select(date, cpi_ypc = value) %>%
  mutate(source = "RBA/ABS") %>%
  bind_rows(lr_cpi_ypc) %>%
  mutate(date = floor_date(date, unit = "month")) %>%
  arrange(date)


#---------------------------------------------------------------------
# Wages

# Avg weekly earnings, historical
lr_awe <- butlin_t7 %>%
  mutate(source = "LR", date = as.Date(ISOdate(year,06,30))) %>%
  select(date, awe, source) %>%
  # adjust dates to match ABS
  mutate(date = floor_date(date, unit = "month")) %>%
  # Make annual percentage change
  mutate(awe_yoy = awe/dplyr::lag(awe,1)*100-100)

# Get current AWE
short_awe <- read_awe(wage_measure = c("awe"),
                      sex = c("persons"),
                      sector = c("total"),
                      state = c("all")) %>%
  select(date, awe=value) %>%
  mutate(date = floor_date(as.Date(date), unit = "month")+months(1))


# Hardcoded from ABS data
# Total earnings, only reflects male wages before September 1981
hard_awe <- read_excel(path = "data/ABS AWE Historical.xlsx", sheet="Data") %>%
  mutate(date = as.Date(date))


# splice with current AWE
more_awe <- hard_awe %>%
  add_row(short_awe) %>%
  # Make annual percentage change from quarterly
  mutate(awe_yoy = awe/dplyr::lag(awe,4)*100-100) %>%
  # Remove overlap for combining with historical
  filter(date>=as.Date("1967-09-01"))

# Cut historical data short for splicing
all_awe <- lr_awe %>%
  filter(date<as.Date("1967-09-01")) %>%
  add_row(more_awe) %>%
  select(-awe)


#=====================================================================
# Transform data

# Make ex-post real rate, todays inflation and one year ago interest rate
# Make everything quarterly
lr_yield_bills_q <- lr_yield_bills %>%
  mutate(qtr = lubridate::quarter(date, with_year = T)) %>%
  # Make quarter average
  group_by(qtr) %>%
  summarise(yield_bills = mean(yield_bills)) %>%
  mutate(date = yq(qtr)+months(2)) %>%
  select(-qtr)
# Make real rate, different for quarterly or annual data, as long as not using prior to CPI quarterly
maxdate <- as.Date("1970-06-01")
real_rate <- lr_cpi_ypc %>%
  inner_join(lr_yield_bills_q) %>%
  # Lag interest rate one year (1 step if annual, or 4 if quarterly)
  mutate(real_rate = if_else(date < maxdate,
                             dplyr::lag(yield_bills) - cpi_ypc,
                             dplyr::lag(yield_bills,n=4) - cpi_ypc) ) %>%
  # Remove in between values which are wrong
  filter(!(date >= as.Date("1969-09-01") & date <= as.Date("1970-03-01"))) %>%
  select(date, real_rate, source)



# Combine tibbles for multipanel
multidata <- reduce(list(lr_ur,
                         lr_yield_bills,
                         lr_cpi_ypc,
                         real_rate,
                         all_awe),
               full_join,
               by = "date") %>%
  arrange(date) %>%
  select(-starts_with("source"))

# Convert to long, drop unneeded columns, since Federation
multidata <- multidata %>%
  filter(date >= "1901-06-01") %>%
  pivot_longer(-date, names_to = "series", values_to = "value") %>%
  na.omit() %>%
  mutate(series = case_when(series=="tot" ~ "Terms of trade",
                            series=="cpi_ypc" ~ "CPI inflation",
                            series=="yield_bills" ~ "Interest rate",
                            series=="unemp_rate" ~ "Unemployment rate",
                            series=="misery" ~ "Misery index",
                            series=="real_rate" ~ "Real interest rate",
                            series=="rgdp_yoy" ~ "Real GDP growth",
                            series=="awe_yoy" ~ "Wage growth") )

# Order
multidata <- multidata %>%
  mutate(order = factor(series,
                        levels = c("Unemployment rate","CPI inflation","Wage growth","Real interest rate","Interest rate"),
                        labels = 1:length(unique(series)),
                        ordered = TRUE) )



#=====================================================================
# Viz - Long run unemployment

lr_ur_chart_now <- lr_ur %>%
  ggplot(aes(x = date, y = unemp_rate)) +
  geom_line() +

  scale_colour_manual(values = c(grattan_darkred, grattan_red)) +
  grattan_y_continuous(limits = c(0, 20),
                       labels = function(x)paste0(x, "%")) +
  theme_grattan() +
  theme(axis.title = element_blank()) +
  scale_x_date(breaks = seq.Date(as.Date("1900-06-30"),
                                 as.Date("2020-06-30"),
                                 "20 years"),
               date_labels = "%Y",
               expand = expansion(mult = c(0.05, 0.15))) +
  geom_segment(aes(x = as.Date("1900-06-30"),
                                                  y = lr_ur %>% filter(date == max(date)) %>% select(unemp_rate) %>% unlist(),
                                                  xend = lr_ur %>% filter(date == max(date)) %>% mutate(date2=paste0(date)) %>% select(date2) %>% unlist() %>% as.Date(),
                                                  yend = lr_ur %>% filter(date == max(date)) %>% select(unemp_rate) %>% unlist(),
                                                 ), colour = grattan_yellow, lwd = 1) +
                    grattan_point_filled(data = ~filter(., date == max(date)) %>% filter(date == max(date))) +
              grattan_label(data = ~ filter(.,date == max(date)),
                aes(label = lr_ur %>% filter(date == max(date)) %>% mutate(date2=paste0(date)) %>% select(date2) %>% unlist() %>% as.Date() %>% format(format="%B \n%Y")),
                nudge_x = 700,
                hjust = 0, colour = grattan_yellow) +
  labs(title = "Unemployment is down to a level not seen in 50 years",
       subtitle = paste0("Unemployment rate, June 1901 to ",format(max(lr_ur$date),format="%B %Y")),
       caption = "Notes: Monthly seasonally adjusted data from 1978, quarterly unadjusted data from 1966 to 1978, and annual data before 1966. Sources: ABS 6202.0; ABS historical LFS; Butlin, Dixon and Lloyd (2014)." )

lr_ur_chart_now



#=====================================================================
# Viz - Long run business cycle

# Labeller
labelmaker <- function(x) {
  ifelse(x >= 50,
         x, paste0(x, "%"))
}


# blank dummy for limits
dummy <- tibble(date = rep(as.Date("1960-06-30"),2 )) %>%
  mutate('Unemployment rate' = c(0,15),
         'CPI inflation' = c(-5,30),
         'Real interest rate' = c(-10,20),
         'Interest rate' = c(-1,25),
         'Misery index' = c(0,30),
         'Terms of trade' = c(50,200),
         'Wage growth' = c(-5,30),
         'Real GDP growth' = c(-5,10)) %>%
  pivot_longer(-date, names_to = "series", values_to = "value") %>%
  mutate(order = rep(1:length(unique(series)),2))


lr_buscycle_chart <- multidata %>%
  filter(series == "Unemployment rate" | series == "CPI inflation" | series == "Wage growth" | series == "Real interest rate") %>%
  filter(date > as.Date("1955-06-01")) %>%
  ggplot(aes(x = date, y = value, col = reorder(series,as.numeric(order)))) +
  geom_line() +
  geom_blank(data= dummy %>% filter(series == "Unemployment rate" | series == "CPI inflation" | series == "Wage growth" | series == "Real interest rate") ) +
  facet_wrap(vars(reorder(series,as.numeric(order))), nrow = length(unique(multidata$series)), scales = "free") +
  grattan_colour_manual(length(unique(multidata$series))) +
  grattan_y_continuous(labels = labelmaker) +
  theme_grattan(background = "box") +
  theme(axis.title = element_blank()) +
  scale_x_date(breaks = seq.Date(as.Date("1955-06-01"),
                                 as.Date("2020-06-30"),
                                 "10 years"),
               date_labels = "%Y",
               expand = expansion(mult = c(0.05, 0.05))) +
  labs(title = "The 1970-80s were very costly",
       caption = paste0("Notes: Unemployment rate is monthly seasonally adjusted data from 1978, quarterly unadjusted data from 1966 to 1978, and annual data before 1966. ",
                        "CPI inflation is year-ended quarterly data from June 1923, and financial-year-ended annual data beforehand. ",
                        "Wage growth is year-ended average weekly earnings (total), quarterly from September 1967, but only reflects male wages before September 1981. ",
                        "The real interest rate is ex-post. The interest rate is the quarter-average annualised rate on three-month bank-accepted bills. ",
                        "Sources: Butlin, Dixon and Lloyd (2014); ABS historical LFS; ABS 6202.0 & 6302.0; RBA Tables F1.1 & G1" ) )

lr_buscycle_chart






