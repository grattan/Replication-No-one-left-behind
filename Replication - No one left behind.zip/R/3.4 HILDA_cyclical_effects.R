#==============================================================
# HILDA: Effect of GDP on income etc (Stone 2016; Cervini-Pla 2015)
# NOTE: Needs database from HILDA_data.R
# Project: Full Employment
# Alex Ballantyne
# 12 May 2022
#==============================================================


# packages ---------------------------------------------------------------------

library(tidyverse)
library(fy)
library(grattantheme)
library(readabs)
library(readxl)
library(purrr)
library(lubridate)
library(stats)
library(forcats)

library(plm)
library(car) # for linearHypothesis
library(fixest)
library(data.table) # For flag/L/F lead lag | remotes::install_github("NickCH-K/pmdplyr")

library(haven) # read read STATA files

library(gtools)  #for quantcut

#=====================================================================
# Control

rm(list=ls())

# Define panel index and time vars
panel = c("xwaveid","year")

# Threshold for real labinc growth tirmming outliers
labinc_thresh = 1000

# Base directory
basepath <- here::here()
setwd(basepath)

# Import utility functions
source("R/utilities.R")

# HILDA data directory (STATA files)
hildapath <- "C:/Users/HILDA"
setwd(hildapath)


#=====================================================================•
# Import data

load(paste0(hildapath,"/DataBase.RData"))


#---------------------------------------------------------------------
# Pull GDP

gdp <- read_abs(series_id = c("A2304402X","A2304418T","A2304404C")) %>%
  select(date, value, series_id) %>%
  pivot_wider(names_from = series_id, values_from = value)
gdp <- gdp %>%
  rename(gdp = A2304402X,   # GDP, chain vol, SA, $Mill
         gdp_curr = A2304418T,  # GDP, current prices, SA, $Mill
         gdp_capita = A2304404C # GDP per capita, chain vol, SA, $
  ) %>%
  select(-starts_with("A"))


##TEST - GDP per capita doesn't make a difference
# gdp <- gdp %>%
#   mutate(gdp = gdp_capita)


# Make fin year average
fygdp <- gdp %>%
  mutate(year = date2fy(date)) %>%
  group_by(year) %>%
  summarise(gdp_fy = sum(gdp),
            gdp_curr_fy = sum(gdp_curr) ) %>%
  mutate(year = fy2yr(year))

# Make FY growth
fygdp <- fygdp %>%
  mutate(gdp_fy_yoy = gdp_fy/dplyr::lag(gdp_fy)*100-100,
         gdp_curr_fy_yoy = gdp_curr_fy/dplyr::lag(gdp_curr_fy)*100-100)

# Make log diffs
fygdp <- fygdp %>%
  mutate(gdp_fy_ln = log(gdp_fy),
         gdp_fy_ln_d = gdp_fy_ln - dplyr::lag(gdp_fy_ln))

#---------------------------------------------------------------------
# Pull CPI

cpi <- read_cpi()

# Make fin year average, don't bother rebasing
fycpi <- cpi %>%
  mutate(year = date2fy(date)) %>%
  group_by(year) %>%
  summarise(cpi_fy = mean(cpi)) %>%
  mutate(year = fy2yr(year))



#=====================================================================
# Transform data

# Cull some stuff to preserve puny memory
data <- data %>%
  select(c(xwaveid, year, hhid, age, age_group, sex, state, atsi, tenure, uni, tafe, school), #one
         starts_with(c("cob", "exp", "unemp", "nilf", "emp", "tran", "es",
                       "educ", "hrs", "lab", "inc", "bus", "inv", "oth",
                       "wage", "ret", "net", "prop", "max",
                       "hhw", "hhs", "hhi", "mar", "indu", "oif", "hour")) )


#-----------------------------------
# Match GDP & unemployment & CPI

data <- data %>%
  left_join(fygdp, by="year") %>%
  left_join(fycpi, by="year")


#---------------------------------------------------------------------
# Make covariates etc

# Some basics
data <- data %>%
  mutate(age2 = age^2,
         age3 = age^3,
         female = (sex==2)*1,
         atsi = (atsi>=2)*1,
         foreign_born = (cob_brief>=3)*1,
         labinc_ln = log(labinc+1),
         real_labinc = labinc/(cpi_fy/100),
         real_labinc_ln = log(real_labinc+1),
         super = oifppi, # regular private pensions
         real_capinc = (invinc+businc+super)/(cpi_fy/100),
         tenure_3yr = (tenure>=3)*1 )



# Make panel lead/lags from utility function: function(DATA,panel,delta,leads,lags,varlist)
varlist = c("labinc","real_labinc","labinc_ln","real_labinc_ln",
            "real_capinc","hours",
            "emp_pct","nilf_pct","unemp_pct")
data <- panelleadlags(data,panel,1,0,1,varlist)


# Growth rates
data <- data %>%
  mutate(labinc_growth = labinc/l1_labinc*100-100,
         real_labinc_growth = real_labinc/l1_real_labinc*100-100,
         real_capinc_growth = real_capinc/l1_real_capinc*100-100,
         hours_growth = hours/l1_hours*100-100,
         hours_change = hours - l1_hours,
         bounded_real_labinc_growth = (real_labinc-l1_real_labinc)/((real_labinc+l1_real_labinc)/2)*100 ) %>%

  # Clean values
  mutate(labinc_growth = if_else(is.na(labinc_growth) | is.nan(labinc_growth) | is.infinite(labinc_growth),
                                 NA_real_,
                                 labinc_growth),
         real_labinc_growth = if_else(is.na(real_labinc_growth) | is.nan(real_labinc_growth) | is.infinite(real_labinc_growth),
                                 NA_real_,
                                 real_labinc_growth),
         real_capinc_growth = if_else(is.na(real_capinc_growth) | is.nan(real_capinc_growth) | is.infinite(real_capinc_growth),
                                 NA_real_,
                                 real_capinc_growth),
         hours_growth = if_else(is.na(hours_growth) | is.nan(hours_growth) | is.infinite(hours_growth),
                                    NA_real_,
                                hours_growth)  )

# Unemp rate change
data <- data %>%
  mutate(unemp_pct_ppt = unemp_pct - l1_unemp_pct,
         emp_pct_ppt = emp_pct - l1_emp_pct)


# Log diffs
data <- data %>%
  mutate(labinc_ln_d = labinc_ln - l1_labinc_ln,
         real_labinc_ln_d = real_labinc_ln - l1_real_labinc_ln )


# Stone 2016 "employed sample" = positive labinc in period t-1
# AB samples exclude outliers 
data <- data %>%
  mutate(emp_samp = (emp_pct>95 & l1_emp_pct>95 &
                     real_labinc_growth<labinc_thresh )*1,
         cap_samp = (l1_real_capinc!=0 & real_capinc_growth<labinc_thresh & real_capinc_growth>-labinc_thresh)*1 ,
         labinc_samp = (real_labinc_growth<labinc_thresh)*1,
         hours_change_samp = (data$hours_change<75 & data$hours_change>-75)*1  )


# Make quantile factor by year
p <- c(0.2,0.4,0.6,0.8)
varlist = c("labinc","networth","wage","inc_gross_tot")
namelist = c("Low","2nd","3rd","4th","High")
data <- makequants(data,"year",varlist,p)
data <- cleanquants(data,"xwaveid",varlist,namelist,"ter")



#=====================================================================
# Core variable for regressions

# Lagged quintiles groups and controls


# Make panel lead/lags from utility function: function(DATA,panel,delta,leads,lags,varlist)
varlist = c("labinc_ter","networth_ter","wage_ter","inc_gross_tot_ter",
            "quant_labinc","quant_networth","quant_wage","quant_inc_gross_tot",
            "age","age2","educ","educ_det","marital","female","foreign_born","industry","state")
data <- panelleadlags(data,panel,1,0,1,varlist)



#=====================================================================
# Filter data

# Labour force sample definition
#
data <- data %>%
  mutate(keep = if_else(age < 65 & retired != 1 & nilf_pct < 50 & l1_nilf_pct < 50, 1, 0))


# Make separate interactions for ease
data <- data %>%
  mutate(int_yoy_gdp_qwageter1 = gdp_fy_yoy*(l1_wage_ter=="Low"),
         int_yoy_gdp_qwageter2 = gdp_fy_yoy*(l1_wage_ter=="2nd"),
         int_yoy_gdp_qwageter3 = gdp_fy_yoy*(l1_wage_ter=="3rd"),
         int_yoy_gdp_qwageter4 = gdp_fy_yoy*(l1_wage_ter=="4th"),
         int_yoy_gdp_qwageter5 = gdp_fy_yoy*(l1_wage_ter=="High"),
         int_yoy_gdp_qwelter1 = gdp_fy_yoy*(l1_networth_ter=="Low"),
         int_yoy_gdp_qwelter2 = gdp_fy_yoy*(l1_networth_ter=="2nd"),
         int_yoy_gdp_qwelter3 = gdp_fy_yoy*(l1_networth_ter=="3rd"),
         int_yoy_gdp_qwelter4 = gdp_fy_yoy*(l1_networth_ter=="4th"),
         int_yoy_gdp_qwelter5 = gdp_fy_yoy*(l1_networth_ter=="High") )

# Use lagged year-specific as controls, keep NA obs
data <- data %>%
  mutate(control_wage = factor(l1_quant_wage,exclude=""),
         control_networth = factor(l1_quant_networth,exclude="") )


#=====================================================================
# Regressions - AB preferred


# AB preferred model, no retirees/older workers, no outliers
reg_labinc <- feols(real_labinc_growth ~
                      int_yoy_gdp_qwageter1 + int_yoy_gdp_qwageter2 + int_yoy_gdp_qwageter3 +  int_yoy_gdp_qwageter4 + int_yoy_gdp_qwageter5 +
                      control_wage +
                      control_networth +
                      l1_age*factor(l1_educ_det) +
                      l1_age2*factor(l1_educ_det) +
                      factor(l1_marital) | industry + state + xwaveid ,
                    data=data, panel.id=panel,
                    subset = (data$keep==1 & data$labinc_samp==1 ) )
summary(reg_labinc,cluster = c( "xwaveid", "state","wage_ter"))
ct_reg_labinc = coeftable(reg_labinc, cluster = c("state", "wage_ter","xwaveid")) %>% data.frame()



# Rinse and repeat for wealth
# >>
reg_labinc_wealth <- feols(real_labinc_growth ~
                      int_yoy_gdp_qwelter1 + int_yoy_gdp_qwelter2 + int_yoy_gdp_qwelter3 + int_yoy_gdp_qwelter4 + int_yoy_gdp_qwelter5 +
                        control_wage +
                        control_networth +
                      l1_age*factor(l1_educ_det) +
                      l1_age2*factor(l1_educ_det) +
                      factor(l1_marital) | industry + state + xwaveid,
                    data=data, panel.id=panel,
                    subset = (data$keep==1 & data$labinc_samp==1 ) )
summary(reg_labinc_wealth, cluster = c("state", "networth_ter","xwaveid"))
ct_reg_labinc_wealth = coeftable(reg_labinc_wealth, cluster = c("state", "networth_ter","xwaveid")) %>% data.frame()



#=====================================================================
# Regressions - AB preferred - Investment and business income

# AB preferred model CAP income, inc retirees but cull zero inv/bus people and outliers
reg_capinc <- feols(real_capinc_growth ~
                      int_yoy_gdp_qwageter1 + int_yoy_gdp_qwageter2 + int_yoy_gdp_qwageter3 + int_yoy_gdp_qwageter4 + int_yoy_gdp_qwageter5 +
                      control_wage +
                      control_networth +
                      l1_age*factor(l1_educ_det) +
                      l1_age2*factor(l1_educ_det) +
                      factor(l1_marital) | industry + state + xwaveid ,
                    data=data, panel.id=panel,
                    subset = (data$cap_samp==1) )
summary(reg_capinc)
ct_reg_capinc = coeftable(reg_capinc, cluster = c("state", "wage_ter","xwaveid")) %>% data.frame()


# As above with networth quantiles
# >> similar
reg_capinc_networth <- feols(real_capinc_growth ~
                         int_yoy_gdp_qwelter1 + int_yoy_gdp_qwelter2 + int_yoy_gdp_qwelter3 + int_yoy_gdp_qwelter4 + int_yoy_gdp_qwelter5 +
                           control_wage +
                           control_networth +
                         l1_age*factor(l1_educ_det) +
                         l1_age2*factor(l1_educ_det) +
                         factor(l1_marital) | industry + state + xwaveid ,
                       data=data, panel.id=panel,
                       subset = (data$cap_samp==1) )
summary(reg_capinc_networth)
ct_reg_capinc_networth = coeftable(reg_capinc_networth, cluster = c("state", "networth_ter","xwaveid")) %>% data.frame()



#=====================================================================
# Unemployment response

# AB unemployment model [basically Okun] FULL sample ex oldies/retires, outliers and NILFs (either t or t-1)
# >> Similar with employment instead of unemployment
reg_unemp <- feols(unemp_pct_ppt ~
                     int_yoy_gdp_qwageter1 + int_yoy_gdp_qwageter2 + int_yoy_gdp_qwageter3 + int_yoy_gdp_qwageter4 + int_yoy_gdp_qwageter5 +
                     control_wage +
                     control_networth +
                     l1_age*factor(l1_educ_det) +
                     l1_age2*factor(l1_educ_det) +
                     factor(l1_marital) | industry + state + xwaveid,
                   data=data, panel.id=panel,
                   subset = (data$keep==1) )
summary(reg_unemp)
ct_reg_unemp = coeftable(reg_unemp, cluster = c("state", "wage_ter","xwaveid")) %>% data.frame()

# As above with networth quantiles
# >> similar as above
reg_unemp_networth <- feols(unemp_pct_ppt ~
                              int_yoy_gdp_qwelter1 + int_yoy_gdp_qwelter2 + int_yoy_gdp_qwelter3 + int_yoy_gdp_qwelter4 + int_yoy_gdp_qwelter5 +
                              control_wage +
                              control_networth +
                              l1_age*factor(l1_educ_det) +
                              l1_age2*factor(l1_educ_det) +
                              factor(l1_marital) | industry + state + xwaveid,
                            data=data, panel.id=panel,
                            subset = (data$keep==1) )
summary(reg_unemp_networth)
ct_reg_unemp_networth = coeftable(reg_unemp_networth, cluster = c("state", "networth_ter","xwaveid")) %>% data.frame()


# Repeast for employment so graphs are similar
reg_emp <- feols(emp_pct_ppt ~
                     int_yoy_gdp_qwageter1 + int_yoy_gdp_qwageter2 + int_yoy_gdp_qwageter3 + int_yoy_gdp_qwageter4 + int_yoy_gdp_qwageter5 +
                     control_wage +
                     control_networth +
                     l1_age*factor(l1_educ_det) +
                     l1_age2*factor(l1_educ_det) +
                     factor(l1_marital) | industry + state + xwaveid,
                   data=data, panel.id=panel,
                   subset = (data$keep==1) )
summary(reg_emp)
ct_reg_emp = coeftable(reg_emp, cluster = c("state", "wage_ter","xwaveid")) %>% data.frame()

# As above with networth quantiles
# >> similar as above
reg_emp_networth <- feols(emp_pct_ppt ~
                              int_yoy_gdp_qwelter1 + int_yoy_gdp_qwelter2 + int_yoy_gdp_qwelter3 + int_yoy_gdp_qwelter4 + int_yoy_gdp_qwelter5 +
                            control_wage +
                            control_networth +
                              l1_age*factor(l1_educ_det) +
                              l1_age2*factor(l1_educ_det) +
                              factor(l1_marital) | industry + state + xwaveid,
                            data=data, panel.id=panel,
                            subset = (data$keep==1) )
summary(reg_emp_networth)
ct_reg_emp_networth = coeftable(reg_emp_networth, cluster = c("state", "networth_ter","xwaveid")) %>% data.frame()



#=====================================================================
# Hours response

reg_hours <- feols(hours_change ~
                     int_yoy_gdp_qwageter1 + int_yoy_gdp_qwageter2 + int_yoy_gdp_qwageter3 + int_yoy_gdp_qwageter4 + int_yoy_gdp_qwageter5 +
                     control_wage +
                     control_networth +
                     l1_age*factor(l1_educ_det) +
                     l1_age2*factor(l1_educ_det) +
                     factor(l1_marital) | industry + state + xwaveid,
                   data=data, panel.id=panel,
                   subset = (data$keep==1 & data$hours_change_samp==1) )
summary(reg_hours, cluster = c("state", "wage_ter","xwaveid"))
ct_reg_hours = coeftable(reg_hours, cluster = c("state", "wage_ter","xwaveid")) %>% data.frame()


reg_hours_wealth <- feols(hours_change ~
                     int_yoy_gdp_qwelter1 + int_yoy_gdp_qwelter2 + int_yoy_gdp_qwelter3 + int_yoy_gdp_qwelter4 + int_yoy_gdp_qwelter5 +
                       control_wage +
                       control_networth +
                     l1_age*factor(l1_educ_det) +
                     l1_age2*factor(l1_educ_det) +
                     factor(l1_marital) | industry + state + xwaveid,
                   data=data, panel.id=panel,
                   subset = (data$keep==1 & data$hours_change_samp==1) )
summary(reg_hours_wealth, cluster = c("state", "networth_ter","xwaveid"))
ct_reg_hours_wealth = coeftable(reg_hours_wealth, cluster = c("state", "networth_ter","xwaveid")) %>% data.frame()




#=====================================================================
# HOMOG stats
# STATS PRINTED AT END OF FILE

# HOMOG versions

# LABOUR INC
reg_labinc_hom <- feols(real_labinc_growth ~
                          gdp_fy_yoy +
                          control_wage +
                          control_networth +
                          l1_age*factor(l1_educ_det) +
                          l1_age2*factor(l1_educ_det) +
                          factor(l1_marital) | industry + state + xwaveid,
                        data=data, panel.id=panel,
                        subset = (data$keep==1 & data$labinc_samp==1) )

reg_labinc_emp_hom <- feols(real_labinc_growth ~
                              gdp_fy_yoy +
                              control_wage +
                              control_networth +
                              l1_age*factor(l1_educ_det) +
                              l1_age2*factor(l1_educ_det) +
                              factor(l1_marital) | industry + state + xwaveid,
                            data=data, panel.id=panel,
                            subset = (data$emp_samp==1 & data$keep==1) )

# CAPITAL INC
reg_capinc_hom <- feols(real_capinc_growth ~
                      gdp_fy_yoy +
                      control_wage +
                      control_networth +
                      l1_age*factor(l1_educ_det) +
                      l1_age2*factor(l1_educ_det) +
                      factor(l1_marital) | industry + state + xwaveid ,
                    data=data, panel.id=panel,
                    subset = (data$cap_samp==1) )

# UNEMP/EMP
reg_unemp_hom <- feols(unemp_pct_ppt ~
                         gdp_fy_yoy +
                     control_wage +
                     control_networth +
                     l1_age*factor(l1_educ_det) +
                     l1_age2*factor(l1_educ_det) +
                     factor(l1_marital) | industry + state + xwaveid,
                   data=data, panel.id=panel,
                   subset = (data$keep==1) )

reg_emp_hom <- feols(emp_pct_ppt ~
                         gdp_fy_yoy +
                         control_wage +
                         control_networth +
                         l1_age*factor(l1_educ_det) +
                         l1_age2*factor(l1_educ_det) +
                         factor(l1_marital) | industry + state + xwaveid,
                       data=data, panel.id=panel,
                       subset = (data$keep==1) )

# HOURS
reg_hours_hom <- feols(hours_change ~
                         gdp_fy_yoy +
                     control_wage +
                     control_networth +
                     l1_age*factor(l1_educ_det) +
                     l1_age2*factor(l1_educ_det) +
                     factor(l1_marital) | industry + state + xwaveid,
                   data=data, panel.id=panel,
                   subset = (data$keep==1 & data$hours_change_samp==1) )


#=====================================================================
# Viz - COMBO

# All interaction coeffs | feols default se() is clustered by xwaveid only! | use coeftable
which_coeffs <- unlist(gregexpr("int_yoy",rownames(ct_reg_labinc)))>0
# Make vizdata for wage quintiles
vizdata_i <- tibble(coeff = c(ct_reg_labinc$Estimate[which_coeffs],
                              ct_reg_unemp$Estimate[which_coeffs],
                              ct_reg_emp$Estimate[which_coeffs],
                              ct_reg_hours$Estimate[which_coeffs] ),
                    se = c(ct_reg_labinc$Std..Error[which_coeffs],
                           ct_reg_unemp$Std..Error[which_coeffs],
                           ct_reg_emp$Std..Error[which_coeffs],
                           ct_reg_hours$Std..Error[which_coeffs] ),
                    pval = c(ct_reg_labinc$Pr...t..[which_coeffs],
                           ct_reg_unemp$Pr...t..[which_coeffs],
                           ct_reg_emp$Pr...t..[which_coeffs],
                           ct_reg_hours$Pr...t..[which_coeffs] ),
                    var = c(rownames(ct_reg_labinc)[which_coeffs],
                            rownames(ct_reg_unemp)[which_coeffs],
                            rownames(ct_reg_emp)[which_coeffs],
                            rownames(ct_reg_hours)[which_coeffs]),
                    sample = c(rep("Real labour income growth",5),
                               rep("Change in unemployment rate",5),
                               rep("Change in employment rate",5),
                               rep("Change in weekly hours worked",5) )) %>%
  mutate(var = case_when(var == "int_yoy_gdp_qwageter1" ~ "1",
                         var == "int_yoy_gdp_qwageter2" ~ "2",
                         var == "int_yoy_gdp_qwageter3" ~ "3",
                         var == "int_yoy_gdp_qwageter4" ~ "4",
                         var == "int_yoy_gdp_qwageter5" ~ "5"))
# Make vizdata for wealth quintiles
vizdata_w <- tibble(coeff = c(ct_reg_labinc_wealth$Estimate[which_coeffs],
                              ct_reg_unemp_networth$Estimate[which_coeffs],
                              ct_reg_emp_networth$Estimate[which_coeffs],
                              ct_reg_hours_wealth$Estimate[which_coeffs] ),
                    se = c(ct_reg_labinc_wealth$Std..Error[which_coeffs],
                           ct_reg_unemp_networth$Std..Error[which_coeffs],
                           ct_reg_emp_networth$Std..Error[which_coeffs],
                           ct_reg_hours_wealth$Std..Error[which_coeffs] ),
                    var = c(rownames(ct_reg_labinc_wealth)[which_coeffs],
                            rownames(ct_reg_unemp_networth)[which_coeffs],
                            rownames(ct_reg_emp_networth)[which_coeffs],
                            rownames(ct_reg_hours_wealth)[which_coeffs]),
                    pval = c(ct_reg_labinc_wealth$Pr...t..[which_coeffs],
                           ct_reg_unemp_networth$Pr...t..[which_coeffs],
                           ct_reg_emp_networth$Pr...t..[which_coeffs],
                           ct_reg_hours_wealth$Pr...t..[which_coeffs] ),
                    sample = c(rep("Real labour income growth",5),
                               rep("Change in unemployment rate",5),
                               rep("Change in employment rate",5),
                               rep("Change in weekly hours worked",5) )) %>%
  mutate(var = case_when(var == "int_yoy_gdp_qwelter1" ~ "1",
                         var == "int_yoy_gdp_qwelter2" ~ "2",
                         var == "int_yoy_gdp_qwelter3" ~ "3",
                         var == "int_yoy_gdp_qwelter4" ~ "4",
                         var == "int_yoy_gdp_qwelter5" ~ "5"))

# Merge
vizdata <- vizdata_i %>%
  mutate(quintile = "Wage quintiles") %>%
  add_row(vizdata_w) %>%
  mutate(quintile = if_else(is.na(quintile),"Net-worth quintiles",quintile) ) %>%
  mutate(quintile = factor(quintile),
         var = factor(var)) %>%
  # Set order
  mutate(sample = factor(sample, levels = c("Real labour income growth",
                                         "Change in unemployment rate",
                                         "Change in employment rate",
                                         "Change in weekly hours worked") ,ordered = T )) %>%
  # Make error bars and colour
  mutate(ylow = coeff-2*se,
         yhigh = coeff+2*se) %>%
  mutate(col = if_else(pval<0.1,"signif","null")) # 10% threshold



# Plot requires manual tweaking in post
viz_combo_quin <- vizdata %>%
  ggplot(aes(x = quintile, y = coeff, colour = col, fill = col, group = var)) +
  geom_point(position = position_dodge(.8),cex=3.5) +
  geom_linerange(aes(ymin=ylow, ymax=yhigh, colour = col), lwd=1.2,
                position=position_dodge(.8)) +
  facet_wrap(vars(factor(sample)), nrow=4, scales = "free_y") +
  grattan_fill_manual(2) +
  grattan_colour_manual(2) +
  geom_hline(yintercept = 0) +
  grattan_y_continuous(labels = function(x) paste0(x, "ppt")) +
  theme_grattan() +
  theme(axis.ticks.x = element_blank(),
        axis.title.x = element_blank()) +
  scale_x_discrete(name = "Wage quintile") +
  labs(title = "Low-wage and low-wealth workers earn more when the economy grows",
       subtitle = "Change in labour market outcomes for a 1 percentage point increase in GDP growth",
       caption = paste0("Notes: Estimates are from a regression of labour market outcomes on real GDP growth, controlling for factors that affect income over the life cycle. ",
                        "The dots are point estimates and lines are two-standard-error bands. Red dots and lines are statistically significant at the 10 per cent threshold.",
                        "For details, see https://grattan.edu.au/report/no-one-left-behind-why-australia-should-lock-in-full-employment/. ",
                        "Source: Grattan analysis of HILDA Release 20.0, ABS 5206.0 and 6401.0.") )

viz_combo_quin


#=====================================================================
# Viz - WIDE version


viz_combo_quin_wide <- viz_combo_quin + facet_wrap(vars(factor(sample)), nrow=2, scales = "free_y")



#=====================================================================
# Viz - Make rocket go now




  # Fraction outliers removed
  mean(data$real_labinc_growth[data$keep==1]>labinc_thresh, na.rm=T)

  #=====================================================================
  # Print HOMOG stats

  print(paste0("LF sample labour income: ",round(reg_labinc_hom$coefficients["gdp_fy_yoy"],2)))
  print(paste0("Employed sample labour income: ",round(reg_labinc_emp_hom$coefficients["gdp_fy_yoy"],2)))
  print(paste0("Capital sample capital income: ",round(reg_capinc_hom$coefficients["gdp_fy_yoy"],2)))
  print(paste0("LF sample Unemp response: ",round(reg_unemp_hom$coefficients["gdp_fy_yoy"],2)))
  print(paste0("LF sample Emp response: ",round(reg_emp_hom$coefficients["gdp_fy_yoy"],2)))
  print(paste0("LF sample hours: ",round(reg_hours_hom$coefficients["gdp_fy_yoy"],2)))



  #=====================================================================
  # Print WALD tests
  #linearHypothesis(reg_labinc,c("int_yoy_gdp_qwageter1=int_yoy_gdp_qwageter5"), vcov = vcov_cluster(reg_labinc,cluster = c( "xwaveid", "state","wage_ter")))
