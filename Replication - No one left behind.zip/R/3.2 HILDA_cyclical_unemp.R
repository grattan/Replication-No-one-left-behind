#==============================================================
# HILDA: Monthly response of group unemployment rates to cycle
# NOTE: Needs database from HILDA_data.R
# Project: Full Employment
# Alex Ballantyne
# 12 May 2022

#
# WARNING: This file produces chart data that CANNOT be released to the public
#

#==============================================================


# packages ---------------------------------------------------------------------

library(tidyverse)
library(fy)
library(grattantheme)
library(readabs)
library(readxl)
library(purrr)
library(lubridate)
library(stats)

library(seasonal)

library(plm)
library(fixest)
library(data.table) # For flag/L/F lead lag | remotes::install_github("NickCH-K/pmdplyr")

library(haven) # read read STATA files

library(gtools)  #for quantcut

library(srvyr) # Survey package for dplyr

#=====================================================================
# Control

rm(list=ls())

# Define panel index and time vars
panel = c("xwaveid","year")

# Define lead and lag order
leadord = 1
lagord = 5

# Base directory
basepath <- here::here()
setwd(basepath)

# Import utility functions
source("R/utilities.R")

# HILDA data directory (STATA files)
hildapath <- "C:/Users/HILDA"
setwd(hildapath)



#=====================================================================
# Import data

load(paste0(hildapath,"/DataBase.RData"))
# Annual time series too short to see much
# Use monthly from spells data
load(paste0(hildapath,"/DataUnempSpells.RData"))

#---------------------------------------------------------------------
# Pull monthly and finyear average unemployment rate

ur <- read_abs(series_id = "A84423050A") %>%
  select(date, value)
fyur <- ur %>%
  mutate(year = date2fy(date)) %>%
  group_by(year) %>%
  summarise(urate_fy = mean(value)) %>%
  mutate(year = fy2yr(year))



#=====================================================================
# Transform data

# Cull some stuff to preserve puny memory
data <- data %>%
  select(c(xwaveid, year, hhid, age, age_group, sex, state, atsi,  tenure), #one
         starts_with(c("cob", "exp", "unemp", "nilf", "emp", "tran",
                       "educ", "hrs", "lab", "inc", "bus", "inv", "oth",
                       "wage", "ret", "net", "prop", "max",
                       "hhw", "hhs", "hhi", "mar", "indu", "esem",
                       "indust", "occu")) )


#---------------------------------------------------------------------
# Merge unemployment rate
data <- data %>%
  left_join(fyur, by="year")

#---------------------------------------------------------------------
# Make covariates etc

# Some basics
data <- data %>%
  mutate(age2 = age^2,
         female = (sex==2)*1,
         atsi = (atsi>=2)*1,
         foreign_born = (cob_brief>=3)*1,
         self_emp = (esempst > 1)*1 )


# Dates
data <- data %>%
  mutate(date = as_date(hhidate, tz = NULL, format = "%d/%m/%Y"),
         month = floor_date(date, unit = "month"),
         qtr = lubridate::quarter(month, with_year = T),
         finyear = yr2fy(year))


# Make quantile factor by year
p <- c(0.3333,0.6666)
varlist = c("labinc","networth","wage")
namelist = c("Low","Mid","High")
data <- makequants(data,"year",varlist,p)
data <- cleanquants(data,"xwaveid",varlist,namelist,"ter")



#---------------------------------------------------------------------
# Merge into monthly spells as annual time series too short to get much traction

spells <- spells %>%
  rename(year = year_survey,
         month_unemp = month) %>%
  mutate(unemp_month = unemp_month*100,
         nilf_month = nilf_month*100) %>%
  left_join(data, by=c("xwaveid","year"))
# Merge unemployment rate
spells <- spells %>%
  mutate(date = date_unemp) %>%
  left_join(ur, by="date") %>%
  rename(urate = value)

# Kill data to preserve memory
rm(data)

#=====================================================================
# Filter data

# Keep copy
spells_raw <- spells

# ALL: Drop if >= 65 years old or completely retired
# spells <- spells %>%
#   filter(age < 65,
#          retired != 1)

# ALL: Drop if full NILF in month or completely retired
# Removed drop self employed esempst < 2
spells <- spells %>%
  filter(nilf_month == 0,
         retired != 1)



#=====================================================================
# Unemployment incidence by cuts

# Weighted by responding person weight hhwtrp | excluding 2011 top up weight hhwtrpm
# Weight sum should be 15.0 million in wave 1, but is short since culled under 18 year olds in DataBase.RData?

# srvyr way too slow to use
# spells <- spells %>% as_survey(weights = c(hhwtrp))

# Need to exclude top-up for 2011 since no employment calendar in this year
spells <- spells %>%
  mutate(new_weight = if_else(year==2011,hhwtrpm,hhwtrp))

# Overall
unemp_month_full <- spells %>%
  group_by(date_unemp) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  mutate(cat = "Full sample",
         group = "full") %>%
  ungroup()


# Education
unemp_month_educ <- spells %>%
  group_by(date_unemp,educ) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  filter(!is.na(educ)) %>%
  mutate(educ = case_when(educ==1 ~ "High school",
                          educ==2 ~ "Diploma",
                          educ==3 ~ "University")) %>%
  rename(group = educ) %>%
  mutate(cat = "Education") %>%
  ungroup()

# Sex
unemp_month_sex <- spells %>%
  group_by(date_unemp,sex) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  mutate(sex = case_when(sex==1 ~ "Male",
                         sex==2 ~ "Female")) %>%
  rename(group = sex) %>%
  mutate(cat = "Gender") %>%
  ungroup()

# ATSI
unemp_month_atsi <- spells %>%
  group_by(date_unemp,atsi) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  mutate(atsi = case_when(atsi==1 ~ "Indigenous",
                          atsi==0 ~ "Non-Indigenous")) %>%
  rename(group = atsi) %>%
  mutate(cat = "Indigenous") %>%
  ungroup()

# Age
unemp_month_age <- spells %>%
  filter(age < 65) %>%
  group_by(date_unemp,age_group) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  rename(group = age_group) %>%
  mutate(cat = "Age") %>%
  ungroup()

# Wealth
unemp_month_networth <- spells %>%
  filter(!is.na(networth_ter)) %>%
  group_by(date_unemp,networth_ter) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  rename(group = networth_ter) %>%
  mutate(cat = "Net worth") %>%
  ungroup()

# Wage
unemp_month_wage <- spells %>%
  filter(!is.na(wage_ter)) %>%
  group_by(date_unemp,wage_ter) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  rename(group = wage_ter) %>%
  mutate(cat = "Wage") %>%
  ungroup()

# Broad occuption
unemp_month_occ <- spells %>%
  filter(!is.na(occupation_broad_mode)) %>%
  group_by(date_unemp,occupation_broad_mode) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  mutate(occupation_broad_mode = case_when(occupation_broad_mode==1 ~ "Non-routine cognitive",
                                           occupation_broad_mode==2 ~ "Non-routine manual",
                                           occupation_broad_mode==3 ~ "Routine cognitive",
                                           occupation_broad_mode==4 ~ "Routine manual")) %>%
  rename(group = occupation_broad_mode) %>%
  mutate(cat = "Broad occupation") %>%
  ungroup()

# Non Eng COB
unemp_month_cob <- spells %>%
  filter(!is.na(cob_noneng)) %>%
  group_by(date_unemp,cob_noneng) %>%
  summarise(counts = sum(!is.na(unemp_month)),
            unemp_month = weighted.mean(unemp_month,new_weight,na.rm=T)) %>%
  mutate(cob_noneng = case_when(cob_noneng==0 ~ "English-speaking country of birth",
                                           cob_noneng==1 ~ "Non-English-speaking country of birth")) %>%
  rename(group = cob_noneng) %>%
  mutate(cat = "Country of birth") %>%
  ungroup()




# Merge all and add national urate back in
gnames <- ls(pattern="unemp_m")
udata <- reduce(mget(gnames),
                add_row) %>%
  rename(date = date_unemp) %>%
  left_join(ur,by="date") %>%
  rename(urate = value) %>%
  arrange(date)


#
# CHECK MINIMUM COUNTS
#
print(paste("Minimum count from group-specific unemployment rate:", min(udata$counts)))


#-----------------------------------
# Seasonally adjust

# Make ts object for seas()
sadata <- udata %>%
  select(date, group, cat, unemp_month) %>%
  pivot_wider(names_from = c(group,cat), values_from = unemp_month)
tsdata <- sadata %>%
  select(-date) %>%
  map(~ ts(data = .x, start = c(2000,7), frequency = 12) )
# Apply seas()
sadata_out <- map(tsdata, ~ seas(.x)) # Default X-13ARIMA-SEATS adjustment
sadata_out <- map(sadata_out, ~ .x$series$s11)
sadata <- as_tibble(sadata_out) %>%
  mutate(date = sadata$date) %>%
  pivot_longer(-date, names_to = c("group","cat"), values_to = "unemp_month_sa", names_sep = "_")
# Merge into udata
udata <- udata %>%
  full_join(sadata, by=c("date","group","cat")) %>%
  arrange(cat, group, date)
  # Clean
rm(sadata,tsdata,sadata_out)


#=====================================================================
# Correlations/Regressions - group unemployment rate vs cycle

# Simple regs with interactions

# SEX
reg_sex <- lm(unemp_month_sa ~ urate*factor(group), data=udata, subset=udata$cat=="Gender")
summary(reg_sex)

# EDUC
reg_educ <- lm(unemp_month_sa ~ urate*factor(group), data=udata, subset=udata$cat=="Education")
summary(reg_educ)


# AGE
reg_age <- lm(unemp_month_sa ~ urate*factor(group), data=udata, subset=udata$cat=="Age")
summary(reg_age)

# ATSI
reg_atsi <- lm(unemp_month_sa ~ urate*factor(group), data=udata, subset=udata$cat=="Indigenous")
summary(reg_atsi)

# WEALTH
reg_networth <- lm(unemp_month_sa ~ urate*factor(group), data=udata, subset=udata$cat=="Net worth")
summary(reg_networth)

# WAGE
reg_wage <- lm(unemp_month_sa ~ urate*factor(group), data=udata, subset=udata$cat=="Wage")
summary(reg_wage)

# OCC
reg_occupation <- lm(unemp_month_sa ~ urate*factor(group), data=udata, subset=udata$cat=="Broad occupation")
summary(reg_occupation)

# COB
reg_cob <- lm(unemp_month_sa ~ urate*factor(group), data=udata, subset=udata$cat=="Country of birth")
summary(reg_cob)



#=====================================================================
# Individual level predictions

# Set base category for factors
spells <- spells %>%
  mutate(sex = relevel(factor(sex),ref='1'),
         educ = relevel(factor(educ),ref='2'),
         age_group = relevel(factor(age_group),ref="35-54"),
         atsi = relevel(factor(atsi),ref='0'),
         networth_ter = relevel(factor(networth_ter),ref="Mid"),
         wage_ter = relevel(factor(wage_ter),ref="Mid"),
         state = relevel(factor(state),ref='1'),
         self_emp = relevel(factor(self_emp),ref='0'),
         occupation_broad_mode = relevel(factor(occupation_broad_mode),ref='3'),  # Routine cognitive=3
         industry_broad_mode = relevel(factor(industry_broad_mode),ref='4')) # Household services=4

# Make year-month ID
spells <- spells %>%
  mutate(time = make_date(year = year, month = month_unemp, day = 1 ) )

# Make unemp binary version
spells <- spells %>%
  mutate(unemp_month_dummy = (unemp_month > 50)*1 )


# Fixed effects (similar if share of month or binary)
# Main results
indiv_reg_fe <- feols(unemp_month ~
                     urate*factor(sex) + urate*factor(educ) + urate*age + urate*age2 +
                     urate*factor(atsi) + urate*factor(networth_ter) + urate*factor(wage_ter) +
                     urate*factor(industry_broad_mode) + urate*factor(occupation_broad_mode) +
                       urate*factor(state) +  urate*factor(self_emp) + urate*factor(cob_noneng) +
                       factor(month_unemp) | xwaveid ,
                data=spells, panel.id=c("xwaveid","time") )
summary(indiv_reg_fe)


# Fixed effects - LOGIT -> perfect prediction problem -> use brfeglm to see if it matters?
indiv_logit_fe <- feglm(unemp_month_dummy ~
                        urate*factor(sex) + urate*factor(educ) + urate*age + urate*age2 +
                        urate*factor(atsi) + urate*factor(networth_ter) + urate*factor(wage_ter) +
                          urate*factor(industry_broad_mode) + urate*factor(occupation_broad_mode) +
                          urate*factor(state) + urate*factor(self_emp) + urate*factor(cob_noneng) +
                          factor(month_unemp)  | xwaveid ,
                      data=spells, panel.id=c("xwaveid","time"),
                      family = "logit")
summary(indiv_logit_fe)

# No intercations check on urate
indiv_reg_fe_noint <- feols(unemp_month ~
                        urate + factor(sex) + factor(educ) + age + age2 +
                        factor(atsi) + factor(networth_ter) + factor(wage_ter) +
                        factor(industry_broad_mode) + factor(occupation_broad_mode) +
                        factor(state) +  factor(self_emp) + urate*factor(cob_noneng) +
                        factor(month_unemp) | xwaveid ,
                      data=spells, panel.id=c("xwaveid","time"))
summary(indiv_reg_fe_noint)


# sample average age
mean(spells$age[unlist(indiv_reg_fe$obs_selection)])




#-----------------------------------------------
# Individual level marginal effects
# The coefficient is the marginal effect of being in group compared to base
mean(indiv_reg_fe$fitted.values)
mean(spells$unemp_month[indiv_reg_fe$obs_selection$obsRemoved])


# Alternate marginal at average

# Setup
coefs <- coef(indiv_reg_fe)
shock <- 1

# Base averages
design_matrix <- model.matrix(indiv_reg_fe)
design_matrix_avg <- colMeans(design_matrix)

# Find which variables do what
which_age <- unlist(gregexpr(":age",names(indiv_reg_fe$coefficients)))>0
which_levels <- !unlist(gregexpr("urate",names(indiv_reg_fe$coefficients)))>0
which_allints <- !which_age & !which_levels

# Shock averages
design_matrix_shock <- design_matrix
design_matrix_shock[,which_allints] <- (design_matrix_shock[,which_allints]+shock)*(design_matrix_shock[,which_allints]!=0)
design_matrix_shock[,"urate:age"] <- design_matrix[,"age"]*design_matrix_shock[,"urate"]
design_matrix_shock[,"urate:age2"] <- design_matrix[,"age2"]*design_matrix_shock[,"urate"]
design_matrix_shock_avg <- colMeans(design_matrix_shock)

# base
marg_base <- sum(coefs*design_matrix_shock_avg)-sum(coefs*design_matrix_avg)
names(marg_base) <- "urate"

# Marginal effects at average over groups of interest
marg_educ <- margeffsatavg(levels(spells[["educ"]]),indiv_reg_fe,"educ",design_matrix_avg,design_matrix_shock_avg)
marg_sex <- margeffsatavg(levels(spells[["sex"]]),indiv_reg_fe,"sex",design_matrix_avg,design_matrix_shock_avg)
marg_wage_ter <- margeffsatavg(levels(spells[["wage_ter"]]),indiv_reg_fe,"wage_ter",design_matrix_avg,design_matrix_shock_avg)
marg_networth_ter <- margeffsatavg(levels(spells[["networth_ter"]]),indiv_reg_fe,"networth_ter",design_matrix_avg,design_matrix_shock_avg)
marg_occupation_broad_mode <- margeffsatavg(levels(spells[["occupation_broad_mode"]]),indiv_reg_fe,"occupation_broad_mode",design_matrix_avg,design_matrix_shock_avg)



#=====================================================================
# Make latex table


varnames <- c('urate' = "Unemployment rate",
  'urate:factor(sex)1' = "Male",
  'urate:factor(sex)2' = "Female",
  'urate:factor(educ)1' = "High school",
  'urate:factor(educ)2' = "Tafe",
  'urate:factor(educ)3' = "University",
  'urate:factor(age_group)18-34' = "Aged 18-34",
  'urate:factor(age_group)35-54' = "Aged 35-54",
  'urate:factor(age_group)55-64' = "Aged 55-64",
  'urate:age' = "Age",
  'urate:age2' = "Age squared",
  'urate:factor(atsi)1' = "Indigenous",
  'urate:factor(atsi)0' = "Non-Indigenous",
  'urate:factor(networth_ter)Low' = "Low net worth",
  'urate:factor(networth_ter)Mid' = "Mid net worth",
  'urate:factor(networth_ter)High' = "High net worth",
  'urate:factor(wage_ter)Low' = "Low wage",
  'urate:factor(wage_ter)Mid' = "Mid wage",
  'urate:factor(wage_ter)High' = "High wage",
  'urate:factor(state)2' = "VIC",
  'urate:factor(state)3' = "QLD",
  'urate:factor(state)4' = "SA",
  'urate:factor(state)5' = "WA",
  'urate:factor(state)6' = "TAS",
  'urate:factor(state)7' = "NT",
  'urate:factor(state)8' = "ACT",
  'urate:factor(occupation_broad_mode)4' = "Routine manual",
  'urate:factor(occupation_broad_mode)3' = "Routine cognitive",
  'urate:factor(occupation_broad_mode)2' = "Non-routine manual",
  'urate:factor(occupation_broad_mode)1' = "Non-routine cognitive",
  'urate:factor(industry_broad_mode)4' = "Household services",
  'urate:factor(industry_broad_mode)3' = "Business services",
  'urate:factor(industry_broad_mode)2' = "Trade and logistics",
  'urate:factor(industry_broad_mode)1' = "Production and amenities",
  'urate:factor(self_emp)1' = "Self-employed",
  'urate:factor(cob_noneng)1' = "Non-English-speaking country of birth",
  'xwaveid' = "Individual",
  'unemp_month' = "Monthly unemployment")

# Setting a dictionary
setFixest_dict(varnames)

#etable(est, style.df = style.df(depvar.title = "", fixef.title = "",
#                                fixef.suffix = " fixed effect", yesNo = "yes"))

# REQUIRES MANUAL ADJUSTMENT EX POST - particularly adding in tabs (&) between ses to make new column
etable(indiv_reg_fe,
       vcov = vcov_cluster(indiv_reg_fe, cluster = c("factor(networth_ter)", "factor(wage_ter)","xwaveid")),
       keep = varnames,
       tex = TRUE,
       file = paste0(basepath,"Output/indiv_unemployment_reg.tex"),
       se.below = F,
       style.tex = style.tex(var.title = "\\midrule \\emph{Interaction terms}"),
       replace=T)


#=====================================================================
# Quick plot of sense check

hilda_unemployment_rate <- udata %>%
  filter(group=="full") %>%
  ggplot(aes(x=date)) +
  geom_line(aes(y=urate, col="ABS")) +
  geom_line(aes(y=unemp_month_sa, col="HILDA")) +
  grattan_colour_manual(2) +
  theme_grattan() +
  grattan_y_continuous(labels = function(x) paste0(x, "%")) +
  theme(axis.title = element_blank()) +
  grattan_label(data = data.frame(date = c(as.Date("2005-01-01"),as.Date("2016-01-01")),
                                  yval = c(6.5,7.2),
                                  lab = c("ABS Labour\nForce Survey","HILDA")),
                aes(x = date, y = yval, label = lab, col = c("ABS","HILDA") ))  +
  labs(title = "The monthly unemployment rate from HILDA captures key parts of the cycle",
       subtitle = "Unemployment rate, per cent",
       caption = paste0("The monthly unemployment rate from HILDA is derived from employment calendars, weighted by the cross-sectional responding person weights, and seasonally adjusted using X-13ARIMA-SEATS. ",
                        "Source: Grattan analysis of HILDA Release 20.0 and ABS LFS") )
hilda_unemployment_rate




#=====================================================================
# Viz - big ol scatter

scatdata <- udata %>%
  mutate(facet = factor(cat, levels = c("Education",
                                        "Gender",
                                        "Indigenous",
                                        "Age",
                                        "Net worth",
                                        "Labour income",
                                        "Non-labour income",
                                        "Wage",
                                        "Broad industry",
                                        "Broad occupation",
                                        "Country of birth",
                                        "Full sample"), ordered=T))%>%
  mutate(col = case_when(group == "University" ~ "1",
                         group == "Diploma" ~ "2",
                         group == "High school" ~ "3",
                         group == "Female" ~ "1",
                         group == "Male" ~ "2",
                         group == "Non-Indigenous" ~ "1",
                         group == "Indigenous" ~ "2",
                         group == "55-64" ~ "1",
                         group == "35-54" ~ "2",
                         group == "18-34" ~ "3",
                         group == "High" ~ "1",
                         group == "Mid" ~ "2",
                         group == "Low" ~ "3",
                         group == "Business services" ~ "1",
                         group == "Household services" ~ "2",
                         group == "Production and amenities" ~ "3",
                         group == "Trade and logistics" ~ "4",
                         group == "Non-routine cognitive" ~ "1",
                         group == "Routine cognitive" ~ "2",
                         group == "Non-routine manual" ~ "3",
                         group == "Routine manual" ~ "4",
                         group == "Non-English-speaking country of birth" ~ "1",
                         group == "English-speaking country of birth" ~ "2"))


lims = c(0,16) # Keep square?


viz_scatter <- scatdata %>%
  filter(cat != "Full sample" & cat != "Indigenous" & cat != "Country of birth") %>%
  ggplot(aes(x = urate, y = unemp_month_sa, group = group, col = col)) +
  geom_point(cex=3, alpha = 0.1) +
  #geom_line(aes(x=reg_labinc$model$urate_agg,y=reg_labinc$fitted.values), lty=2, lwd=1.25) +
  geom_smooth(method = "lm", se = FALSE , lty=1, lwd=1.25) +
  grattan_y_continuous(labels = function(x) paste0(x, "%"), limits=lims ) +
  facet_wrap(vars(facet), nrow=3) +
  scale_x_continuous(name = "National unemployment rate", labels = function(x) paste0(x, "%"), limits=c(3,9) ) +
  grattan_fill_manual(length(na.omit(unique(scatdata$col)))) +
  grattan_colour_manual(length(na.omit(unique(scatdata$col)))) +
  theme_grattan() +
  grattan_label(data = ~group_by(., group) %>% filter(date == "2011-07-01" & !is.na(group)),
                aes(label = group), label.size = NA,
                nudge_x = 1,
                hjust = 0) +
  labs(title = "Disadvantaged groups benefit most when national unemployment falls",
       subtitle = "Group-specific unemployment rate against national rate, monthly",
       caption = paste0("Notes: Each dot represents the monthly unemployment rate from July 2000 to June 2020. ",
                        "Group-specific unemployment rates are derived from HILDA employment calendars, weighted by the cross-sectional responding person weights, and seasonally adjusted using X-13ARIMA-SEATS. ",
                        "Sources: Grattan analysis of HILDA Release 20.0 and ABS 6202.0") )

viz_scatter


#=====================================================================
# Viz - WIDE version


viz_scatter_wide <- viz_scatter + facet_wrap(vars(facet), nrow=2)



#=====================================================================
# Viz - ATSI scatter

viz_scatter_atsi <- scatdata %>%
  filter(cat == "Indigenous") %>%
  ggplot(aes(x = urate, y = unemp_month_sa, group = group, col = col)) +
  geom_point(cex=3, alpha = 0.4) +
  #geom_line(aes(x=reg_labinc$model$urate_agg,y=reg_labinc$fitted.values), lty=2, lwd=1.25) +
  geom_smooth(method = "lm", se = FALSE , lty=1, lwd=1.5) +
  grattan_y_continuous(labels = function(x) paste0(x, "%"), limits=c(0,31) ) +
  scale_x_continuous(name = "National unemployment rate", labels = function(x) paste0(x, "%"), limits=c(3,8) ) +
  scale_fill_manual(values = c(grattan_orange, grattan_red)) +
  scale_colour_manual(values = c(grattan_orange, grattan_red)) +
  theme_grattan(background = "box") +
  grattan_label(data = ~group_by(., group) %>% filter(date == "2011-07-01" & !is.na(group)),
                aes(label = group), label.size = NA,
                nudge_x = 1,
                hjust = 0) +
  labs(title = "Indigenous Australians face much higher unemployment rates than non-Indigenous Australians",
       subtitle = "Group-specific unemployment rate against national rate, monthly",
       caption = paste0("Notes: Each dot represents the monthly unemployment rate from July 2000 to June 2020. ",
                        "Group-specific unemployment rates are derived from HILDA employment calendars, weighted by the cross-sectional responding person weights, and seasonally adjusted using X-13ARIMA-SEATS. ",
                        "Due to the small sample, the standard errors of estimates for Indigenous unemployment rates average 3 percentage points, about 10 times those of Non-Indigenous estimates. ",
                        "Sources: Grattan analysis of HILDA Release 20.0 and ABS 6202.0") )

viz_scatter_atsi



#=====================================================================
# Viz - multivariate regression
ct_indiv_reg_fe = coeftable(indiv_reg_fe, vcov = vcov_cluster(indiv_reg_fe, cluster = c("factor(networth_ter)", "factor(wage_ter)","xwaveid"))) %>% data.frame()
# All urate coeffs & interactions | feols default se() is clustered by xwaveid only! | use coeftable
which_coeffs <- unlist(gregexpr("urate",rownames(ct_indiv_reg_fe)))>0
# Omit industries and occupations
#which_coeffs <- which_coeffs & !unlist(gregexpr("industry",rownames(ct_indiv_reg_fe)))>0
#which_coeffs <- which_coeffs & !unlist(gregexpr("occupation",rownames(ct_indiv_reg_fe)))>0
vizdata <- tibble(coeff = ct_indiv_reg_fe$Estimate[which_coeffs],
                  se = ct_indiv_reg_fe$Std..Error[which_coeffs],
                  var = rownames(ct_indiv_reg_fe)[which_coeffs],
                  pval = ct_indiv_reg_fe$Pr...t..[which_coeffs]) %>%
  # Reorder
  mutate(order = if_else(var == "urate", -9999, coeff)) %>%
  #Relabel
  mutate(var = case_when(var == "urate" ~ "Unemployment rate",
                         var == "urate:factor(sex)2" ~ "Female",
                         var == "urate:factor(educ)1" ~ "High school",
                         var == "urate:factor(educ)2" ~ "Tafe",
                         var == "urate:factor(educ)3" ~ "University",
                         var == "urate:factor(age_group)18-34" ~ "Aged 18-34",
                         var == "urate:factor(age_group)35-54" ~ "Aged 35-54",
                         var == "urate:factor(age_group)55-64" ~ "Aged 55-64",
                         var == "urate:age" ~ "Age",
                         var == "urate:age2" ~ "Age squared",
                         var == "urate:factor(atsi)1" ~ "Indigenous",
                         var == "urate:factor(atsi)0" ~ "Non-Indigenous",
                         var == "urate:factor(networth_ter)Low" ~ "Low net worth",
                         var == "urate:factor(networth_ter)Mid" ~ "Mid net worth",
                         var == "urate:factor(networth_ter)High" ~ "High net worth",
                         var == "urate:factor(wage_ter)Low" ~ "Low wage",
                         var == "urate:factor(wage_ter)Mid" ~ "Mid wage",
                         var == "urate:factor(wage_ter)High" ~ "High wage",
                         var == "urate:factor(state)2" ~ "VIC",
                         var == "urate:factor(state)3" ~ "QLD",
                         var == "urate:factor(state)4" ~ "SA",
                         var == "urate:factor(state)5" ~ "WA",
                         var == "urate:factor(state)6" ~ "TAS",
                         var == "urate:factor(state)7" ~ "NT",
                         var == "urate:factor(state)8" ~ "ACT",
                         var == "urate:factor(occupation_broad_mode)4" ~ "Routine manual",
                         var == "urate:factor(occupation_broad_mode)3" ~ "Routine cognitive",
                         var == "urate:factor(occupation_broad_mode)2" ~ "Non-routine manual",
                         var == "urate:factor(occupation_broad_mode)1" ~ "Non-routine cognitive",
                         var == "urate:factor(industry_broad_mode)4" ~ "Household services",
                         var == "urate:factor(industry_broad_mode)3" ~ "Business services",
                         var == "urate:factor(industry_broad_mode)2" ~ "Trade and logistics",
                         var == "urate:factor(industry_broad_mode)1" ~ "Production and amenities",
                         var == "urate:factor(self_emp)1" ~ "Self-employed"
                         ) )

# Colours
vizdata <- vizdata %>%
  filter(var != "Unemployment rate") %>%
  mutate(col = if_else(pval<0.01, grattan_red, grattan_lightorange)) # 10% threshold

viz_indiv <- vizdata %>%
  ggplot(aes(x = reorder(var, order), y = coeff, fill = reorder(var, order) )) +
  geom_col() +
  coord_flip() +
  scale_fill_manual(values = vizdata$col[order(vizdata$order)]) +
  geom_errorbar(aes(ymin=coeff-2*se, ymax=coeff+2*se), width=.2, lwd=1,
                position=position_dodge(.9), col=1) +
  theme_grattan(flipped = TRUE) +

  scale_x_discrete(guide = guide_axis(angle = 0)) +
  grattan_y_continuous(labels = function(x) paste0(x,"ppt"), limits = c(-2,2.3)) +
  geom_hline(yintercept = 0) +
  theme(axis.title = element_blank()) +
  labs(title = "Wealth drives individual unemployment sensitivity to the cycle",
       subtitle = "Response of individual unemployment probability to a one percentage-point change in the national rate",
       caption = paste0("Notes: Estimates are from a linear regression of the share of each month spent unemployed ",
                        "on the monthly national unemployment rate interacted with various characteristics, month-specific dummies to control for potential recall bias, and individual fixed effects. ",
                        "The base group is a Non-Indigenous male aged 40 with TAFE or Diploma training, who is in the middle wealth and wage terciles on average, lives in NSW and works in routine cognitive occupations in household services. ",
                        "The estimates are interaction effects (and so add to, or subtract from, the base group). ",
                        "The black lines are two-standard-error bands, clustered by individual, wealth tercile and wage tercile. ",
                        "Source: Grattan analysis of HILDA Release 20.0 and ABS LFS 6202.0") )
viz_indiv



#=====================================================================
# Viz - multivariate regression _ MARGINALS

stat_sig <- vizdata %>% select(var,col)

marg_all = c(marg_base,marg_sex,marg_educ,marg_networth_ter,marg_wage_ter,marg_occupation_broad_mode)
vizdata <- tibble(coeff = marg_all,
                  var = names(marg_all),
                  cat = c("All",
                          rep("Gender",length(marg_sex)),
                          rep("Education",length(marg_educ)),
                          rep("Net worth",length(marg_networth_ter)),
                          rep("Wage",length(marg_wage_ter)),
                          rep("Occupation",length(marg_occupation_broad_mode))) ) %>%
  mutate(cat = factor(cat,levels = c("All","Gender","Education","Net worth","Wage","Occupation"),ordered = T)) %>%
  # Reorder
  mutate(order = if_else(var == "urate", -9999, coeff)) %>%
  #Relabel
  mutate(var = case_when(var == "urate" ~ "",
                         var == "urate:factor(sex)1" ~ "Male",
                         var == "urate:factor(sex)2" ~ "Female",
                         var == "urate:factor(educ)1" ~ "High school",
                         var == "urate:factor(educ)2" ~ "Tafe",
                         var == "urate:factor(educ)3" ~ "University",
                         var == "urate:factor(age_group)18-34" ~ "Aged 18-34",
                         var == "urate:factor(age_group)35-54" ~ "Aged 35-54",
                         var == "urate:factor(age_group)55-64" ~ "Aged 55-64",
                         var == "urate:age" ~ "Age",
                         var == "urate:age2" ~ "Age squared",
                         var == "urate:factor(atsi)1" ~ "Indigenous",
                         var == "urate:factor(atsi)0" ~ "Non-Indigenous",
                         var == "urate:factor(networth_ter)Low" ~ "Low net worth",
                         var == "urate:factor(networth_ter)Mid" ~ "Mid net worth",
                         var == "urate:factor(networth_ter)High" ~ "High net worth",
                         var == "urate:factor(wage_ter)Low" ~ "Low wage",
                         var == "urate:factor(wage_ter)Mid" ~ "Mid wage",
                         var == "urate:factor(wage_ter)High" ~ "High wage",
                         var == "urate:factor(state)2" ~ "VIC",
                         var == "urate:factor(state)3" ~ "QLD",
                         var == "urate:factor(state)4" ~ "SA",
                         var == "urate:factor(state)5" ~ "WA",
                         var == "urate:factor(state)6" ~ "TAS",
                         var == "urate:factor(state)7" ~ "NT",
                         var == "urate:factor(state)8" ~ "ACT",
                         var == "urate:factor(occupation_broad_mode)4" ~ "Routine manual",
                         var == "urate:factor(occupation_broad_mode)3" ~ "Routine cognitive",
                         var == "urate:factor(occupation_broad_mode)2" ~ "Non-routine manual",
                         var == "urate:factor(occupation_broad_mode)1" ~ "Non-routine cognitive",
                         var == "urate:factor(industry_broad_mode)4" ~ "Household services",
                         var == "urate:factor(industry_broad_mode)3" ~ "Business services",
                         var == "urate:factor(industry_broad_mode)2" ~ "Trade and logistics",
                         var == "urate:factor(industry_broad_mode)1" ~ "Production and amenities",
                         var == "urate:factor(self_emp)1" ~ "Self-employed"
  ) ) %>%
  left_join(stat_sig) %>%
  mutate(col = if_else(is.na(col),grattan_lightorange,col))

viz_marg <- vizdata %>%
  ggplot(aes(x = cat, y = coeff, fill = reorder(var, order))) +
  geom_bar(position=position_dodge2(width = 0.9, preserve = "single"), stat="identity") +
  coord_flip() +
  scale_fill_manual(values = vizdata$col[order(vizdata$order)]) +
  scale_colour_manual(values = vizdata$col[order(vizdata$order)]) +
  theme_grattan(flipped = TRUE) +
  scale_x_discrete(guide = guide_axis(angle = 0)) +
  grattan_y_continuous(labels = function(x) paste0(x,"ppt"), limits = c(0,1.5), breaks = seq(0,1.5,0.5), expand_top = 0.15) +
  geom_hline(yintercept = 0) +
  theme(axis.title = element_blank()) +
  grattan_label(aes(label = var, colour = reorder(var, order)),
                position = position_dodge(width = 0.85),  # position dodge with width 1
                hjust = -0.1) +
  labs(title = "Low-wage and low-wealth workers face higher risk of unemployment in a downturn",
       subtitle = "Decrease in the probability of becoming unemployed for each 1 percentage-point decrease in the national unemployment rate",
       caption = paste0("Notes: Estimates are from a linear regression of the share of each month spent unemployed ",
                        "on the monthly national unemployment rate interacted with various characteristics, month-specific dummies, and individual fixed effects. ",
                        "Bars are the average marginal effect of a 1 percentage-point decrease in the national unemployment rate. The red bars are statistically significant differences to the base groups (male, TAFE or Diploma, middle wealth and wage terciles, and routine cognitive occupation) at the 1~per cent threshold. ",
                        "Source: Grattan analysis of HILDA Release 20.0 and ABS LFS 6202.0") )
viz_marg




#=====================================================================
# Viz - output




#=====================================================================
# End note: indigenous monthly unemp standard errors for chart notes
# Note: srvyr is VERY slow
if (FALSE)  {
  spells <- spells %>% as_survey(weights = c(new_weight))

  svy_unemp_month_atsi <- spells %>%
    group_by(date_unemp,atsi) %>%
    summarise(unemp_month = survey_mean(unemp_month,na.rm=T)) %>%
    mutate(atsi = case_when(atsi==1 ~ "Indigenous",
                            atsi==0 ~ "Non-Indigenous")) %>%
    rename(group = atsi) %>%
    mutate(cat = "Indigenous") %>%
    ungroup()

  spells <- spells %>% as_tibble()

  print(paste0("Average standard errors of Indigenous: ",
               mean(filter(unemp_month_atsi_se,group=="Indigenous") %>% select(unemp_month_se) %>% unlist()),
               " and Non-Indigenous: ",
               mean(filter(unemp_month_atsi_se,group=="Non-Indigenous") %>% select(unemp_month_se) %>% unlist()) ) )

  print(paste0("Average standard deviation of estimates Indigenous: ",
               sd(filter(unemp_month_atsi_se,group=="Indigenous") %>% select(unemp_month) %>% unlist()),
               " and Non-Indigenous: ",
               sd(filter(unemp_month_atsi_se,group=="Non-Indigenous") %>% select(unemp_month) %>% unlist()) ) )

}


# Print some group correlation slopes
reg_sex$coefficients[unlist(gregexpr("urate",names(reg_sex$coefficients)))>0]
reg_educ$coefficients[unlist(gregexpr("urate",names(reg_educ$coefficients)))>0]
reg_networth$coefficients[unlist(gregexpr("urate",names(reg_networth$coefficients)))>0]
reg_wage$coefficients[unlist(gregexpr("urate",names(reg_wage$coefficients)))>0]
reg_occupation$coefficients[unlist(gregexpr("urate",names(reg_occupation$coefficients)))>0]
reg_cob$coefficients[unlist(gregexpr("urate",names(reg_cob$coefficients)))>0]

