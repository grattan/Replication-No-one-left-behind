#==============================================================
# HILDA: Effect of local labour market outcomes on income and unemployment
# NOTE: Needs database from HILDA_data.R
# Project: Full Employment
# Alex Ballantyne
# 12 May 2022

#
# Note: This uses data from Bishop and Greenland (2021) https://www.rba.gov.au/publications/rdp/2021/2021-09.html
#

#==============================================================


# packages ---------------------------------------------------------------------

library(tidyverse)
library(fy)
library(grattantheme)

library(readxl)
library(purrr)
library(lubridate)
library(stats)

library(plm)
library(car) # for linearHypothesis
library(fixest)
library(data.table) # For flag/L/F lead lag | remotes::install_github("NickCH-K/pmdplyr")

library(haven) # read read STATA files

library(gtools)  #for quantcut

#=====================================================================
# Control

rm(list=ls())

# Define panel index and time vars
panel = c("xwaveid","year")

# Define lead and lag order
leadord = 1
lagord = 5

# Base directory
basepath <- here::here()
setwd(basepath)

# Import utility functions
source("R/utilities.R")

# HILDA data directory (STATA files)
hildapath <- "C:/Users/HILDA"
setwd(hildapath)


# Bishop & Greenland 2021 Directory
bishpath <- "Bishop-Greenland/rdp-2021-09-supplementary-information/output"



#=====================================================================
# Import data

load(paste0(hildapath,"/DataBase.RData"))



#=====================================================================
# Transform data

# Cull some stuff to preserve puny memory
data <- data %>%
  select(c(xwaveid, year, hhid, age, age_group, sex, state, postcode, atsi, tenure, uni, tafe, school), #one
         starts_with(c("cob", "exp", "unemp", "nilf", "emp", "tran", "es",
                       "educ", "hrs", "lab", "inc", "bus", "inv", "oth",
                       "wage", "ret", "net", "prop", "max",
                       "hhw", "hhs", "hhi", "mar", "indu", "occ")) )


#---------------------------------------------------------------------
# Make covariates etc

# Some basics
data <- data %>%
  mutate(age2 = age^2,
         age3 = age^3,
         female = (sex==2)*1,
         atsi = (atsi>=2)*1,
         foreign_born = (cob_brief>=3)*1,
         self_emp = (esempst > 1)*1,
         unemp_anycal = (unemp_pct>0)*1,
         nilf_50cal = (nilf_pct>50)*1  )


# Dates
data <- data %>%
  mutate(date = as_date(hhidate, tz = NULL, format = "%d/%m/%Y"),
         month = floor_date(date, unit = "month"),
         qtr = lubridate::quarter(month, with_year = T),
         finyear = yr2fy(year))


# Make quantile factor by year
p <- c(0.3333,0.6666)
varlist = c("labinc","networth","wage")
namelist = c("Low","Mid","High")
data <- makequants(data,"year",varlist,p)
data <- cleanquants(data,"xwaveid",varlist,namelist,"ter")



#=====================================================================
# Match Bishop & Greenland 2021 Local Labour Markets (LLM) dataset
# Additional output file from "99_ABdataforR.do"
# both files use financial year ending X

setwd(basepath)
setwd(bishpath)
llmdata <- read_dta(file = "AB_Stata_to_R.dta") # LLM clusters master data with SA2 (2016 & 2011 5-digit)

# Match and drop urate outlier
data <- data %>%
  mutate(sa2_2011_short = hhssa2) %>%
  left_join(llmdata, by = c("sa2_2011_short","year") ) %>%
  filter(urate<=30)

# Keep pwd as HILDA in case save data
setwd(hildapath)



#=====================================================================
# Filter data

# ALL: Drop if >= 65 years old or completely retired
# ALL: Drop if labinc <= 0
data <- data %>%
  filter(age < 65,
         retired != 1)




#-------------------------------------------------
# Version similar to cyclical_unemp regression
data <- data %>%
mutate(sex = relevel(factor(sex),ref='1'),
       educ = relevel(factor(educ),ref='2'),
       age_group = relevel(factor(age_group),ref="35-54"),
       atsi = relevel(factor(atsi),ref='0'),
       networth_ter = relevel(factor(networth_ter),ref="Mid"),
       wage_ter = relevel(factor(wage_ter),ref="Mid") )


# Clustering changes the result markedly...
#
unemp_urate_multi <- feols(unemp_pct ~
                        urate*factor(sex) + urate*factor(educ) + urate*age + urate*age2 +
                        urate*factor(atsi) + urate*factor(networth_ter) + urate*factor(wage_ter) +
                        urate*factor(industry_broad_mode) + urate:factor(occupation_broad_mode) +
                        urate*factor(state) +  urate*factor(self_emp) + urate*factor(cob_noneng)  | xwaveid + llm + year ,
                      data=data, panel.id=panel)
summary(unemp_urate_multi ,cluster = c("xwaveid","llm","year"))
summary(unemp_urate_multi,cluster = c("xwaveid","llm","factor(networth_ter)", "factor(wage_ter)"))
#coeftable(unemp_urate_multi, cluster = c("xwaveid","llm","year","factor(networth_ter)", "factor(wage_ter)"))



#=====================================================================
# Make latex table


varnames <- c('urate' = "Unemployment rate",
              'urate:factor(sex)1' = "Male",
              'urate:factor(sex)2' = "Female",
              'urate:factor(educ)1' = "High school",
              'urate:factor(educ)2' = "Diploma",
              'urate:factor(educ)3' = "University",
              'urate:factor(age_group)18-34' = "Aged 18-34",
              'urate:factor(age_group)35-54' = "Aged 35-54",
              'urate:factor(age_group)55-64' = "Aged 55-64",
              'urate:age' = "Age",
              'urate:age2' = "Age squared",
              'urate:factor(atsi)1' = "Indigenous",
              'urate:factor(atsi)0' = "Non-Indigenous",
              'urate:factor(networth_ter)Low' = "Low net worth",
              'urate:factor(networth_ter)Mid' = "Mid net worth",
              'urate:factor(networth_ter)High' = "High net worth",
              'urate:factor(wage_ter)Low' = "Low wage",
              'urate:factor(wage_ter)Mid' = "Mid wage",
              'urate:factor(wage_ter)High' = "High wage",
              'urate:factor(state)2' = "VIC",
              'urate:factor(state)3' = "QLD",
              'urate:factor(state)4' = "SA",
              'urate:factor(state)5' = "WA",
              'urate:factor(state)6' = "TAS",
              'urate:factor(state)7' = "NT",
              'urate:factor(state)8' = "ACT",
              'urate:factor(occupation_broad_mode)4' = "Routine manual",
              'urate:factor(occupation_broad_mode)3' = "Routine cognitive",
              'urate:factor(occupation_broad_mode)2' = "Non-routine manual",
              'urate:factor(occupation_broad_mode)1' = "Non-routine cognitive",
              'urate:factor(industry_broad_mode)4' = "Household services",
              'urate:factor(industry_broad_mode)3' = "Business services",
              'urate:factor(industry_broad_mode)2' = "Trade and logistics",
              'urate:factor(industry_broad_mode)1' = "Production and amenities",
              'urate:factor(self_emp)1' = "Self-employed",
              'xwaveid' = "Individual",
              'llm' = "Local labour market",
              'year' = "Year")
            # 'factor(networth_ter)' = "Net-worth terciles",
            # 'factor(wage_ter)' = "Wage terciles")

# Setting a dictionary
setFixest_dict(varnames)

#etable(est, style.df = style.df(depvar.title = "", fixef.title = "",
#                                fixef.suffix = " fixed effect", yesNo = "yes"))

# REQUIRES MANUAL ADJUSTMENT EX POST - particularly adding in tabs (&) between ses to make new column
# VERY different when clustering on wage/wealth terciles as well
etable(unemp_urate_multi,
       cluster = c("xwaveid","llm","year"),
       keep = varnames,
       tex = TRUE,
       file = paste0(basepath,"Output/llm_unemployment_reg.tex"),
       se.below = F,
       style.tex = style.tex(var.title = "\\midrule \\emph{Interaction terms}"),
       replace=T)






