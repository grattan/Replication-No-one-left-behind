#==============================================================
# Basic RBA Phillips curve
# Project: Full Employment
# Alex Ballantyne, specification taken from Bishop & Greenland (2021) Is PC still a curve
# 12 May 2022

#
# Note: requires MARTIN workfile from RDP website
#

#==============================================================

library(tidyverse)
library(readabs)
library(readrba)
library(readxl)
library(grattantheme)
library(ggtext)
library(ggrepel)
library(lubridate)
library(glue)

library(hexView)  # for readEViews
library(sandwich) # for robust SEs
library(lmtest) # to display robust SEs


#=====================================================================
# Control

rm(list=ls())

# Base directory
#basepath <- here::here()
basepath <- "C:/Users/abball/Dropbox (Grattan Institute)/Macro policy/Data and analysis/2022 Full employment/"
setwd(basepath)

# Import utility functions
source("R/utilities.R")

#=====================================================================
# Import data as per specification

# WPI uses ABS index as better accuracy, private: A2713846W; total: A2713849C

wpi <- read_abs(series_id = "A2713846W") %>%
  select(date, wpi = value) %>%
  mutate(wpi = wpi/dplyr::lag(wpi)*100-100)

# Pull unemployment rate, quarter average and first difference
urate <- read_abs(series_id = "A84423050A") %>%
  select(date, urate = value) %>%
  mutate(qtr = lubridate::quarter(as.Date(date), with_year = T)) %>%
  group_by(qtr) %>%
  summarise(urate = mean(urate)) %>%
  mutate(date = yq(qtr)+months(2)) %>%
  select(-qtr) %>%
  mutate(durate = urate-dplyr::lag(urate))

# Pull domestic final demand deflator, make year-ended change
dfdd <- read_abs(series_id = "A2303726A") %>%
  select(date, dfdd = value) %>%
  mutate(dfdd_yoy = (dfdd/dplyr::lag(dfdd,4))*100-100) %>%
  mutate(dfdd_yoy = dfdd_yoy/4)

# Pull Martin data
martin <- readEViews(filename = "MARTIN/rdp-2019-07-supplementary-information/martin_public.wf1", time.stamp = T, as.data.frame = F)
pi_e <- tibble(pi_e = martin$PI_E, date = as.Date(martin$Date)+months(2) ) %>%
  filter(pi_e != min(pi_e)) %>%
  mutate(pi_e = pi_e/4)
nairu <- tibble(nairu = martin$TLUR, date = as.Date(martin$Date)+months(2) ) %>%
  filter(nairu != min(nairu))



#=====================================================================
# Transform data

# Extend nairu and inflation expectations to end 2019 (assume constant)
extra_pi_e <- tibble(pi_e = rep(pi_e %>% filter(date == max(date)) %>% select(pi_e) %>% unlist(),3),
                     date = seq.Date(as.Date("2019-06-01"),
                                     as.Date("2019-12-01"),
                                     "3 months") )
pi_e <- pi_e %>%
  add_row(extra_pi_e)
extra_nairu <- tibble(nairu = rep(nairu %>% filter(date == max(date)) %>% select(nairu) %>% unlist(),3),
                      date = seq.Date(as.Date("2019-06-01"),
                                      as.Date("2019-12-01"),
                                      "3 months") )
nairu <- nairu %>%
  add_row(extra_nairu)

# Combine data & cut sample @ end 2019
data <- wpi %>%
  left_join(urate) %>%
  left_join(dfdd) %>%
  left_join(pi_e) %>%
  left_join(nairu) %>%
  select(-dfdd) %>%
  filter(date <= "2019-12-01")

# Make nonlinear urate gap term
data <- data %>%
  mutate(ugap = (urate-nairu)/urate) %>%
  mutate(nairu_over_urate = nairu/urate)
  #select(-urate,-nairu)

# Make lags for convenience
data <- data %>%
  mutate(wpi_lag = dplyr::lag(wpi),
         ugap_lag = dplyr::lag(ugap),
         durate_lag = dplyr::lag(durate),
         urate_lag = dplyr::lag(urate),
         nairu_lag = dplyr::lag(nairu),
         pi_e_lag = dplyr::lag(pi_e))
  #select(-ugap,-durate)

# Make time
data <- data %>%
  mutate(t = 1:n())


#=====================================================================
# Run model

pc <- lm(wpi ~ wpi_lag +  ugap_lag + durate_lag + dfdd_yoy + pi_e_lag,
         data = data)
coeftest(pc, vcov = NeweyWest(pc) ) #  MacKinnon White, Stata "robust" is "HC1"


#=====================================================================
# Make graph data

# Combine contributions
vizdata <- data.frame(t( t(cbind(1, data$wpi_lag, data$ugap_lag, data$durate_lag, data$dfdd_yoy, data$pi_e_lag)) * coef(pc) ) )
names(vizdata) <- c("Intercept", "Lagged WPI", "Unemployment gap", "Unemployment change", "Demand deflator", "Inflation expectations")
vizdata <- vizdata %>%
  mutate(date = data$date) %>%
  filter(date >= as.Date("1998-03-01"))

# Make yearly and demean, remove int
vizdata <- vizdata %>%
  mutate(across(-date, ~ .x + dplyr::lag(.x,1) + dplyr::lag(.x,2) + dplyr::lag(.x,3) ) ) %>%
  mutate(across(-date, ~ .x - mean(.x, na.rm=T) ) ) %>%
  select(-Intercept) %>%
  filter(date >= as.Date("1998-12-01"))

# Make long
vizdata <- vizdata %>%
  pivot_longer(-date) %>%
  mutate(order = case_when(name == "Lagged WPI" ~ 3,
                           name == "Unemployment gap" ~ 1,
                           name == "Unemployment change" ~ 2,
                           name == "Inflation expectations" ~ 4,
                           name == "Demand deflator" ~ 5 ))

# Make separate WPI
wpidata <- data %>%
  filter(date >= as.Date("1998-03-01")) %>%
  select(date, 'Actual WPI' = wpi) %>%
  mutate(across(-date, ~ .x + dplyr::lag(.x,1) + dplyr::lag(.x,2) + dplyr::lag(.x,3) ) ) %>%
  mutate(across(-date, ~ .x - mean(.x, na.rm=T) ) ) %>%
  filter(date >= as.Date("1998-12-01"))


#=====================================================================
# Viz - Basic PC

ue_colours <- c(
  "Unemployment gap" = grattan_red, #grattan_darkorange
  "Unemployment change" = grattan_darkorange, #grattan_red
  "Lagged WPI" = grattan_lightorange, #grattan_orange3
  "Inflation expectations" = grattan_yellow, #grattan_orange5
  "Demand deflator" = grattan_lightyellow, #
  "Actual WPI" = "black"
)
ue_levels <- names(ue_colours)


viz_pc <- vizdata %>%
  ggplot(aes(x = date)) +
  geom_col(aes(y = value, fill = reorder(name,-order)), colour=NA) +
  geom_line(data = wpidata,
             aes(x = date, y = `Actual WPI`),
             colour = "black") +
  grattan_y_continuous(labels = function(x) paste0(x,"%"), limits = c(-1.5,1.5)) +
  theme_grattan() +
  theme(axis.title = element_blank()) +
  scale_fill_manual(values = ue_colours) +
  scale_colour_manual(values = ue_colours) +
  geom_hline(yintercept = 0) + #Anika: added in to make 0% line more visible
  geom_gtext_legend(ue_colours, collapse = "<br>",
                    position_x = as.Date("2000-03-01"), position_y = -0.75,
                    vjust = 1, hjust = 0) +
  labs(title = "A weak labour market weighs on wage growth",
       subtitle = "Contributions to wage Phillips Curve model, year-ended deviations from own mean",
       caption = paste0("Notes: WPI = Wage Price Index. The Phillips curve model follows the current specification for private WPI used by the RBA, as detailed in Appendix A of Bishop and Greenland (2021), estimated over March 1998 to December 2019. Year-ended measures are four-quarter sums. ",
                        "The NAIRU and trend inflation expectations series are taken from the Eviews workfile for the RBA MARTIN model and assumed to be constant after March 2019. ",
                        "Source: Grattan analysis of ABS WPI, LFS, National Accounts, and Ballantyne et al. (2019).") )
viz_pc


#=====================================================================
# Viz - output

