#==============================================================
# HILDA: Decompose HOUSEHOLD income into labour, investment, transfers, tax
# NOTE: Needs database from HILDA_data.R
# Project: Full Employment
# Alex Ballantyne
# 12 May 2022
#==============================================================


# packages ---------------------------------------------------------------------

library(tidyverse)
library(fy)
library(grattantheme)
library(readabs)
library(readxl)
library(purrr)
library(lubridate)
library(stats)

library(gtools)  #for quantcut

library(srvyr) # Survey package for dplyr

library(matrixStats) # for weighted median

#=====================================================================
# Control

rm(list=ls())
gc()

# Define panel index and time vars
panel = c("xwaveid","year")

# Base directory
basepath <- here::here()
setwd(basepath)

# Import utility functions
source("R/utilities.R")

# HILDA data directory (STATA files)
hildapath <- "C:/Users/HILDA"
setwd(hildapath)



#=====================================================================
# Import data

# Use Raw database
load(paste0(hildapath,"/DataRaw.RData"))

# Reduce sample based on whether interviewed and age >= 18 years (OR USE DataRaw FOR GINI etc)
data <- data %>%
  filter(hgni == 0 & hgage >= 18)


#---------------------------------------------------------------------
# Pull CPI

cpi <- read_cpi()

# Make fin year average, don't bother rebasing
fycpi <- cpi %>%
  mutate(year = date2fy(date)) %>%
  group_by(year) %>%
  summarise(cpi_fy = mean(cpi)) %>%
  mutate(year = fy2yr(year))

# rebase
base_2020 <- fycpi %>%
  filter(year == 2020) %>%
  select(cpi_fy) %>%
  as.numeric()
fycpi <- fycpi %>%
  mutate(deflator_2020 = cpi_fy/base_2020)


#=====================================================================
# Transform data


#-----------------------------------
# MatchCPI

data <- data %>%
  left_join(fycpi, by="year")


#---------------------------------------------------------------------
# Make covariates etc

# Household wealth
data <- data %>%
  mutate(hnetworth = hwnwip - hwnwin,
         hproperty_eq = case_when(hwtpeqp >= 0 & hwtpeqn >= 0 ~ hwtpeqp-hwtpeqn),
         hproperty_val = case_when(hwtpval >= 0 ~ hwtpval) )

#---------------------------------------------------------------------
# Income decomp model

# hinc_gross_disp = hlabinc + hinvinc + hbusinc + hsuper + htransfers + hothinc - hinc_gross_tax
#                          |_______ capital inc ______|


# Household income
data <- data %>%
  mutate(hinc_gross_tot = case_when(hifeftp >= 0 & hifeftn >= 0 ~ hifeftp-hifeftn),
         hinc_gross_tax = case_when(hiftxtp >= 0 & hiftxtn >= 0 ~ hiftxtp-hiftxtn),
         hinc_gross_disp = case_when(hifditp >= 0 & hifditn >= 0 ~ hifditp-hifditn),
         hlabinc = case_when(hiwsfei >= 0 ~ hiwsfei),
         hinvinc = case_when(hifinip >= 0 & hifinin >= 0 ~ hifinip-hifinin),
         hbusinc = case_when(hibifip >= 0 & hibifin >= 0 ~ hibifip-hibifin),
         hsuper = hifppi, # regular private pensions
         hcapinc = hinvinc + hbusinc + hsuper,
         htransfers = hifapti,
         hothinc = hinc_gross_disp - hlabinc - hcapinc - htransfers + hinc_gross_tax )

# Make all real
data <- data %>%
  mutate(hinc_gross_tot = hinc_gross_tot/deflator_2020,
         hinc_gross_tax = hinc_gross_tax/deflator_2020,
         hinc_gross_disp = hinc_gross_disp/deflator_2020,
         hlabinc = hlabinc/deflator_2020,
         hinvinc = hinvinc/deflator_2020,
         hbusinc = hbusinc/deflator_2020,
         hsuper = hsuper/deflator_2020,
         hcapinc = hcapinc/deflator_2020,
         htransfers = htransfers/deflator_2020,
         hothinc = hothinc/deflator_2020 )


# Find individual with most obs and assume household tracks them
# hhid is different each wave, and numbers repeat!
data <- data %>%
  mutate(newhhid = paste0(year,hhid)) %>%
  group_by(xwaveid) %>%
  mutate(nobs = n()) %>%
  ungroup() %>%
  group_by(newhhid) %>%
  mutate(longest = (nobs == max(nobs))*1 ) %>%
  ungroup()


# Working age household if more than half of over 18s are both 18-64 and not retired
# Retired if more than half of HH are 65+ and retired
data <- data %>%
  mutate(retired = case_when(rtcage>0 | rtcomp==1 ~ 1,
                             TRUE ~ 0),
         work_age = case_when(hgage < 65 & hgage >= 18 ~ 1,
                              TRUE ~ 0) ) %>%
  mutate(lf_person = (retired==0 & work_age==1)*1) %>%
  mutate(retired_person = (retired==1 & work_age==0)*1) %>%
  group_by(newhhid) %>%
  mutate(lf_hh = mean(lf_person)>0.5) %>%
  mutate(retired_hh = mean(retired_person)>0.5) %>%
  ungroup()


# Collapse to one person per household per year, taking first xwaveid that has longest run
hdata <- data %>%
  filter(longest==1) %>%
  arrange(newhhid,xwaveid) %>%
  group_by(newhhid) %>%
  mutate(n = 1:n()) %>%
  filter(n==1) %>%
  ungroup() %>%
  arrange(xwaveid,year)


# Make quantile factor by year
p <- c(0.2,0.4,0.6,0.8)
varlist = c("hlabinc","hnetworth","hinc_gross_tot")
namelist = c("Low","2nd","3rd","4th","High")
hdata <- makequants(hdata,"year",varlist,p)
hdata <- cleanquants(hdata,"xwaveid",varlist,namelist,"ter")



#=====================================================================
# Filter data

# ALL: Drop if >= 65 years old or completely retired
# lfdata <- data %>%
#   filter(age < 65,
#          retired != 1)


# Filter for labour force sample (working age not retired)
hdata_lf <- hdata %>%
  filter(lf_hh) %>%
  group_by(xwaveid) %>%
  mutate(nobs = n()) %>%
  ungroup()


#=====================================================================
# Decomposition over time - working age

# hinc_gross_disp = hlabinc + hinvinc + hbusinc + hsuper + htransfers + hothinc - hinc_gross_tax
#                          |_______ capital inc ______|

# Average version
decomp_year <- hdata_lf %>%
  group_by(year) %>%
  summarise(hlabinc = weighted.mean(hlabinc,hhwth,na.rm=T),
            hcapinc = weighted.mean(hcapinc,hhwth,na.rm=T),
            htransfers = weighted.mean(htransfers,hhwth,na.rm=T),
            hothinc = weighted.mean(hothinc,hhwth,na.rm=T),
            hinc_gross_tax = weighted.mean(hinc_gross_tax,hhwth,na.rm=T),
            hinc_gross_disp = weighted.mean(hinc_gross_disp,hhwth,na.rm=T),
            hinc_gross_tot = weighted.mean(hinc_gross_tot,hhwth,na.rm=T) ) %>%
  # Make tax negative
  mutate(hinc_gross_tax = -hinc_gross_tax)

# Average component shares
decomp_average <- decomp_year %>%
  mutate(across(c(hlabinc,hcapinc,htransfers,hothinc) , ~.x/hinc_gross_tot)) %>%
  select(-hinc_gross_tax,-hinc_gross_disp,-hinc_gross_tot)


# Remove total for later graphing
decomp_year <- decomp_year %>%
  select(-hinc_gross_tot)


# Median version
decomp_year_med <- hdata_lf %>%
  group_by(year) %>%
  summarise(hlabinc = weightedMedian(hlabinc,hhwth,na.rm=T),
            hcapinc = weightedMedian(hcapinc,hhwth,na.rm=T),
            htransfers = weightedMedian(htransfers,hhwth,na.rm=T),
            hothinc = weightedMedian(hothinc,hhwth,na.rm=T),
            hinc_gross_tax = weightedMedian(hinc_gross_tax,hhwth,na.rm=T),
            hinc_gross_tot = weightedMedian(hinc_gross_tot,hhwth,na.rm=T),
            hinc_gross_disp = hlabinc + hcapinc + htransfers + hothinc - hinc_gross_tax ) %>%
  # Make tax negative
  mutate(hinc_gross_tax = -hinc_gross_tax)

# Median component shares
decomp_med <- decomp_year_med %>%
  mutate(across(c(hlabinc,hcapinc,htransfers,hothinc) , ~.x/hinc_gross_tot)) %>%
  select(-hinc_gross_tax,-hinc_gross_disp,-hinc_gross_tot)


# Remove total for later graphing
decomp_year_med <- decomp_year_med %>%
  select(-hinc_gross_tot)



#=====================================================================
# Viz - decomp over time

library(scales)

# Colour, order and label maps
colmap <- tibble(name = c("hlabinc","hcapinc","htransfers","hothinc","hinc_gross_tax","hinc_gross_disp"),
                 col = grattan_pal(6))
ordmap <- tibble(name = c("hlabinc","hcapinc","htransfers","hothinc","hinc_gross_tax","hinc_gross_disp"),
                 ord = c(1,3,2,4,5,6))
labmap <- tibble(name = c("hlabinc","hcapinc","htransfers","hothinc","hinc_gross_tax","hinc_gross_disp"),
                 lab = c("Labour","Capital","Transfers","Other","Tax","Disposable"))

# Make chart go now
vizdata <- decomp_year %>%
  select(-hinc_gross_disp) %>%
  pivot_longer(-year) %>%
  left_join(ordmap) %>%
  left_join(colmap) %>%
  left_join(labmap) %>%
  mutate(ylab = rep(c(60000,137000,127000,148000,-10000),dim(decomp_year)[1])) %>%
  arrange(year,ord)

viz_decomp_years <- vizdata %>%
  ggplot(aes(x = year)) +
  geom_area(aes(y = value, fill = reorder(col,-ord)), colour = NA) +
  geom_line(data = select(decomp_year,year,hinc_gross_disp) ,
            aes(x = year, y = hinc_gross_disp),
            colour = 1) +
  geom_hline(yintercept = 0) +
  theme_grattan() +
  grattan_y_continuous(labels=dollar, limits = c(-35000,175000), breaks = seq(-25000,175000,25000)) +
  theme(axis.title = element_blank()) +
  scale_fill_manual(values = grattan_pal(6)[1:5]) +
  scale_colour_manual(values = grattan_pal(6)[1:5]) +
  scale_x_continuous(expand = expansion(mult = c(0.05, 0.18))) +
  grattan_label(data = ~filter(.,year==2020),
                aes(y = ylab, label = lab, colour = reorder(col,-ord)),
                hjust = 0, nudge_x  = 0.5) +
  labs(title = "Labour income drives household disposable income",
       subtitle = "Average annual real household disposable income by component, 2020 dollars",
       caption = "Note: Working-age households (those where more than half of the adults are 18-64 years old and not retired) weighted by the HILDA cross-sectional household weights. Deflated using CPI. Source: Grattan analysis of HILDA Release 20.0")

viz_decomp_years


#=====================================================================
# Viz - output




#=====================================================================
# Postscript summary stats for text

# Average component shares over time

decomp_average
print("Average component shares for average working-age household")
decomp_average %>% summarise(hlabinc = mean(hlabinc), hcapinc = mean(hcapinc), htransfers = mean(htransfers))

print("Average INCOME from component for MEDIAN working-age household")
decomp_year_med %>% summarise(hlabinc = mean(hlabinc), hcapinc = mean(hcapinc), htransfers = mean(htransfers))


