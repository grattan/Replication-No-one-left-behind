#==============================================================
# HILDA: Set up database for individuals
# Project: Full Employment
# Alex Ballantyne
# 12 May 2022
#==============================================================

# NOTE --------------------------------------------------------
# hildareadR package set up for confidential release, not restricted release
# trace(read_hilda, edit=T) and change "0c.dta" to "0u.dta"
# -------------------------------------------------------------


# packages ---------------------------------------------------------------------

library(tidyverse)
library(fy)
library(grattantheme)

library(readxl)
library(purrr)
library(lubridate)
library(stats)

#library(haven)  # haven for read_dta
library(hildareadR) # modify for restricted release: trace(read_hilda, edit=T) and change "0c.dta" to "0u.dta"

library(fixest) # for panel data manipulation
library(data.table) # For flag/L/F lead lag

#=====================================================================
# Control

rm(list=ls())


#***********************************************
# Flag for pulling the data from the source files
# If this is FALSE, the transformations etc are conducted on the previously saved RData
RefreshData = FALSE
#***********************************************

# Which release
release <- 20

# Base directory
basepath <- here::here()
# HILDA data directory (STATA files)
hildapath <- "C:/Users/HILDA"
setwd(hildapath)

# List of variable names (prefixes of any length)
housevars <- c("hhid","hhpcode","hhssa","hhstate","hghhm","hhadst","hhd","hhpers","hhura","hhsad",
               "hhresp","hhwte","hhidate","hhw","tcr","hh0","hh5","hh1","hi","hht")
indivvars <- c("hgage","hgni","hgi","hgsex","hgyob","edhigh1","an","lnwte","mrcurr")
incomevars <- c("oi","ti","bnf","bif","wsfe","wsce","tx")
wealthvars <- c("hw")
labvars <- c("es","jb","eh","rt","jsmin","cap","cau","can", "pj")
miscvars <- c("hhpcode", "losat","gh")

domain <- unique(c(housevars,indivvars,incomevars,wealthvars,labvars,miscvars))


# List of waves
waves <- 1:release



#=====================================================================
# Import data, cull sample, save raw

if(RefreshData) {
  data <- read_hilda(domain, waves=waves, dir=hildapath, release=release)
  # Order and add year
  data <- data %>%
    arrange(xwaveid,wave) %>%
    mutate(year = case_when(wave == "a" ~ 2001,
                            wave == "b" ~ 2002,
                            wave == "c" ~ 2003,
                            wave == "d" ~ 2004,
                            wave == "e" ~ 2005,
                            wave == "f" ~ 2006,
                            wave == "g" ~ 2007,
                            wave == "h" ~ 2008,
                            wave == "i" ~ 2009,
                            wave == "j" ~ 2010,
                            wave == "k" ~ 2011,
                            wave == "l" ~ 2012,
                            wave == "m" ~ 2013,
                            wave == "n" ~ 2014,
                            wave == "o" ~ 2015,
                            wave == "p" ~ 2016,
                            wave == "q" ~ 2017,
                            wave == "r" ~ 2018,
                            wave == "s" ~ 2019,
                            wave == "t" ~ 2020,
                            wave == "u" ~ 2021,
                            wave == "v" ~ 2022,
                            wave == "w" ~ 2023,
                            wave == "x" ~ 2024,
                            wave == "y" ~ 2025,
                            wave == "z" ~ 2026  )) %>%
    relocate(xwaveid,year,wave)
  # Save
  save(data,file=paste0(hildapath,"/DataRaw.RData"))
} else {
  load(paste0(hildapath,"/DataRaw.RData"))
}

#=====================================================================
# Transform data

# Reduce sample based on whether interviewed and age >= 18 years (OR USE DataRaw FOR GINI etc)
data <- data %>%
  filter(hgni == 0 & hgage >= 18)


#---------------------------------------------------------------------
# Rename variables

data <- data %>%
  rename(#postcode = hhpcode,
         state = hhstate,
         age = hgage,
         sex = hgsex,
         atsi = anatsi,
         cob_brief = anbcob,
         experience_totyrs = ehtjb,
         unemp_totyrs = ehtuj,
         transfers = bnfapti
  )

data <- data %>%
  mutate(topup = if_else(hhtup==0 | is.na(hhtup),0,1))


#---------------------------------------------------------------------
# Construct combo variables
# See User Manual for income/wealth model etc
# https://melbourneinstitute.unimelb.edu.au/__data/assets/pdf_file/0009/3562857/HILDA-User-Manual-Release-19.0.pdf
# See p22 mising variable convention
#-1 Not asked: question skipped due to answer to a preceding question
#-2 Not applicable
#-3 Don’t know
#-4 Refused or not answered
#-5 Invalid multiple response (SCQ only)
#-6 Value implausible (as determined after intensive checking)
#-7 Unable to determine value
#-8 No Self-Completion Questionnaire returned and matched to individual record
#-9 Non-responding household
#-10 Non-responding person (Combined File only)

# Education
data <- data %>%
  mutate(uni = (edhigh1> 0 & edhigh1 < 4)*1,
         tafe = (edhigh1> 3 & edhigh1 < 8)*1,
         school = (edhigh1> 5 & edhigh1 < 10)*1,
         educ = case_when(uni == 1 ~ 3,
                          tafe == 1 ~ 2,
                          school == 1 ~ 1 ),
         educ_det = edhigh1)

# Age groups
data <- data %>%
  mutate(age_group = case_when(age >= 18 & age < 35 ~ "18-34",
                               age >= 35 & age < 55 ~ "35-54",
                               age >= 55 & age < 65 ~ "55-64",
                               age >= 65  ~ "65+" ) )

# Born in non-english speaking country
data <- data %>%
  mutate(cob_noneng = (cob_brief ==3)*1)



# Employment - CURRENT STATUS
data <- data %>%
  mutate(emp = (esbrd == 1)*1,
         unemp = (esbrd == 2)*1,
         nilf = (esbrd == 3)*1)


# Unemployment per cent of fin year categorical
data <- data %>%
  mutate(unemp_pct = if_else(capune>=0,capune,NA_real_),
         nilf_pct = if_else(capnlf>=0,capnlf,NA_real_),
         emp_pct = if_else(capj>=0,capj,NA_real_),
         fteduc_pct = if_else(capeft>=0,capeft,NA_real_),
         pteduc_pct = if_else(capept>=0,capeft,NA_real_),
         unemp_mths = unemp_pct/100*12,
         nilf_mths = nilf_pct/100*12,
         emp_mths = emp_pct/100*12 ) %>%
  # did not use
  mutate(unemp_pct_cat = case_when(unemp_pct == 0 ~ 0,
                                   unemp_pct > 0 & unemp_pct <= 25 ~ 1,
                                   unemp_pct > 25 & unemp_pct <= 75 ~ 2,
                                   unemp_pct > 75 & unemp_pct < 100 ~ 3,
                                   unemp_pct == 100 ~ 4 ))


# Clean total experience and unemp - did not use
data <- data %>%
  mutate(experience_totyrs = case_when(experience_totyrs >= 0 ~ experience_totyrs),
         unemp_totyrs = case_when(unemp_totyrs >= 0 ~ unemp_totyrs) )



# Hours deficit or surplus (hrs per week preferred - hrs per week usually worked)
# Frequent large negative values
data <- data %>%
  mutate(hours = if_else(jbhruc>=-1,jbhruc,NA_real_),
         hours = if_else(jbhruc==-1,0,hours),
         # did not use
         hours_prefer = if_else(jbhrcpr!=2 & jbprhr>=0 & jbhruc>=0,
                              jbprhr-jbhruc,
                              0 ),
         # Underemployment consistent with ILO https://journals.sagepub.com/doi/10.1177/0022185607074921
         underemp = case_when(jbhrcpr==3 & hours<35 & emp==1 ~ 1,
                              jbhrcpr==3 & hours>=35 & emp==1 ~ 0,
                              jbhrcpr>0 & emp==1 ~ 0,
                              TRUE ~ NA_real_))


# Tenure with current employer (years) did not use
data <- data %>%
  mutate(tenure = if_else(jbempt>=0,jbempt,0) )


# Household wealth
data <- data %>%
  mutate(networth = hwnwip - hwnwin,
         # did not use
         property_eq = case_when(hwtpeqp >= 0 & hwtpeqn >= 0 ~ hwtpeqp-hwtpeqn),
         property_val = case_when(hwtpval >= 0 ~ hwtpval) )


# Income: NOTE: negative gross total income only comes from business and investment income, all other streams are >= 0
data <- data %>%
  mutate(inc_gross_tot = case_when(tifeftp >= 0 & tifeftn >= 0 ~ tifeftp-tifeftn),
         inc_gross_tax = case_when(txtottp >= 0 & txtottn >= 0 ~ txtottp-txtottn),
         inc_gross_disp = case_when(tifditp >= 0 & tifditn >= 0 ~ tifditp-tifditn),
         invinc = case_when(oifinip >= 0 & oifinin >= 0 ~ oifinip-oifinin),
         businc = case_when(bifip >= 0 & bifin >= 0 ~ bifip-bifin),
         labinc = case_when(wsfei >= 0 ~ wsfei),
         othinc_gross = inc_gross_tot - invinc - businc - labinc,
         nonlabinc = inc_gross_tot - labinc)


# Hourly wages (see p47 Manual)
data <- data %>%
  mutate(wage = case_when(esbrd==1 & jbhruc>0 & wscei>0 ~ wscei/jbhruc),
         # did not use
         wage_ft = case_when(esdtl==1 & jbhruc>0 & wscei>0 ~ wscei/jbhruc),
         wage_pt = case_when(esdtl==2 & jbhruc>0 & wscei>0 ~ wscei/jbhruc) )


# Industry of employment: ANZSIC 2006 division (1-digit)
data <- data %>%
  mutate(industry = case_when(jbmi61 < 1 ~ "No industry",
                              jbmi61 == 1 ~ "Agriculture, Forestry and Fishing",
                              jbmi61 == 2 ~ "Mining",
                              jbmi61 == 3 ~ "Manufacturing",
                              jbmi61 == 4 ~ "Electricity, Gas, Water and Waste Services",
                              jbmi61 == 5 ~ "Construction",
                              jbmi61 == 6 ~ "Wholesale Trade",
                              jbmi61 == 7 ~ "Retail Trade",
                              jbmi61 == 8 ~ "Accommodation and Food Services",
                              jbmi61 == 9 ~ "Transport, Postal and Warehousing",
                              jbmi61 == 10 ~ "Information Media and Telecommunications",
                              jbmi61 == 11 ~ "Financial and Insurance Services",
                              jbmi61 == 12 ~ "Rental, Hiring and Real Estate Services",
                              jbmi61 == 13 ~ "Professional, Scientific and Technical Services",
                              jbmi61 == 14 ~ "Administrative and Support Services",
                              jbmi61 == 15 ~ "Public Administration and Safety",
                              jbmi61 == 16 ~ "Education and Training",
                              jbmi61 == 17 ~ "Health Care and Social Assistance",
                              jbmi61 == 18 ~ "Arts and Recreation Services",
                              jbmi61 == 19 ~ "Other Services" ) )

# Broad industry groups
# https://www.rba.gov.au/publications/bulletin/2013/mar/pdf/bu-0313-1.pdf
# Production and amenities = 1; Trade and logistics = 2; Business services = 3; Household services = 4
data <- data %>%
  mutate(industry_broad = case_when(jbmi61 < 1 ~ "No industry",
                                    jbmi61 >= 1 & jbmi61 <= 5 ~ "Production and amenities", #Ag, Mining, Manf, Elec, construction
                                    jbmi61 == 6 | jbmi61 == 7 | jbmi61 == 9 ~ "Trade and logistics", # wholesale & retail, transport
                                    jbmi61 >= 10 & jbmi61 <= 14 ~ "Business services", # financial, professional, admin, Info media, rental
                                    jbmi61 == 8 | (jbmi61 >= 15 & jbmi61 <= 19) ~ "Household services" ) ) #Accomm, public admin, educ, health, arts, other


# Make modal industry, removing No Industry
mode <- function(codes){
  which.max(tabulate(codes))
}
ind_names <- c("No industry","Agriculture, Forestry and Fishing","Mining","Manufacturing","Electricity, Gas, Water and Waste Services",
               "Construction","Wholesale Trade","Retail Trade","Accommodation and Food Services","Transport, Postal and Warehousing","Information Media and Telecommunications",
               "Financial and Insurance Services","Rental, Hiring and Real Estate Services","Professional, Scientific and Technical Services","Administrative and Support Services",
               "Public Administration and Safety","Education and Training","Health Care and Social Assistance","Arts and Recreation Services","Other Services" )
ind_names_broad <- c("No industry","Production and amenities","Trade and logistics","Business services","Household services")
data <- data %>%
  mutate(industry_factor = factor(industry, levels=ind_names, labels=0:(length(ind_names)-1)),
         industry_broad_factor = factor(industry_broad, levels=ind_names_broad, labels=0:(length(ind_names_broad)-1)),
         # Remove No Industry to modal over, convert char NAs to real NAs
         temp = as.numeric(addNA(industry_factor))-1,  # Needs minus one for consistency of output
         tempb = as.numeric(addNA(industry_broad_factor))-1,
         temp = if_else(temp==0, NA_real_, as.numeric(temp)),
         tempb = if_else(tempb==0, NA_real_, as.numeric(tempb)) ) %>%
  group_by(xwaveid) %>%
  # Modal and manual override NAs - slow as warnings (needed as don't observe for unemployment)
  mutate(industry_mode = mode(temp),
         industry_broad_mode = mode(tempb),
         check = max(temp,na.rm=T),
         checkb = max(tempb,na.rm=T),
         industry_mode = if_else(is.infinite(check),NA_integer_,industry_mode),
         industry_broad_mode = if_else(is.infinite(checkb),NA_integer_,industry_broad_mode)) %>%
  ungroup() %>%
  select(-temp, -tempb, -check, -checkb)



# Occupation of employment: ANZSCO 2006 division (1-digit)

data <- data %>%
  mutate(occupation = case_when(jbmo61 < 1 ~ "No occupation",
                              jbmo61 == 1 ~ "Managers",
                              jbmo61 == 2 ~ "Professionals",
                              jbmo61 == 3 ~ "Technicians/Trades Workers",
                              jbmo61 == 4 ~ "Personal Service Workers",
                              jbmo61 == 5 ~ "Administrative Workers",
                              jbmo61 == 6 ~ "Sales Workers",
                              jbmo61 == 7 ~ "Machinery Operators",
                              jbmo61 == 8 ~ "Labourers" ))


# Broad occupation groups
# https://www.rba.gov.au/publications/bulletin/2017/sep/3.html#fn4
# Routine manual = 4; Routine cognitive = 3; Non-routine manual = 2; Non-routine cognitive = 1
# data <- data %>%
#   mutate(occupation_broad = case_when(jbmo61 < 1 ~ "No occupation",
#                                     jbmo61 == 7 | jbmo61 == 8 ~ "Routine manual", #Labourers Machinery ops
#                                     jbmo61 == 6 | jbmo61 == 5 ~ "Routine cognitive", # Sales, clerical
#                                     jbmo61 == 4 | jbmo61 == 3 ~ "Non-routine manual", # Community, Technicians
#                                     jbmo61 == 1 | jbmo61 == 2 ~ "Non-routine cognitive" ) ) # Managers, professional

# Borland Coelli 2022 The Australian labour market and the digital economy, Appendix Table 2
data <- data %>%
  mutate(occupation_broad = case_when(jbmo62 < 1 ~ "No occupation",
                                      jbmo62 %in% c(32:34,36:39,70:80,82:84,89) ~ "Routine manual", #Labourers Machinery ops
                                      jbmo62 %in% c(50:63) ~ "Routine cognitive", # Sales, clerical
                                      jbmo62 %in% c(35,81,85,40:45) ~ "Non-routine manual", # Community, Technicians
                                      jbmo62 %in% c(10:14,20:27,30:31) ~ "Non-routine cognitive" ) ) # Managers, professional

# Choose which
# data <- data %>%
#   mutate(occupation_broad = occupation_broad_Borland)

# Make modal occupation, removing No occupation
occ_names <- c("No occupation","Managers","Professionals","Technicians and Trades Workers","Community and Personal Service Workers",
               "Clerical and Administrative Workers","Sales Workers","Machinery Operators and Drivers","Labourers" )
occ_names_broad <- c("No occupation","Non-routine cognitive","Non-routine manual","Routine cognitive","Routine manual")
data <- data %>%
  mutate(occupation_factor = factor(occupation, levels=occ_names, labels=0:(length(occ_names)-1)),
         occupation_broad_factor = factor(occupation_broad, levels=occ_names_broad, labels=0:(length(occ_names_broad)-1)),
         # Remove No occupation to modal over, convert char NAs to real NAs
         temp = as.numeric(addNA(occupation_factor))-1,  # Needs minus one for consistency of output
         tempb = as.numeric(addNA(occupation_broad_factor))-1,
         temp = if_else(temp==0, NA_real_, as.numeric(temp)),
         tempb = if_else(tempb==0, NA_real_, as.numeric(tempb)) ) %>%
  group_by(xwaveid) %>%
  # Modal and manual override NAs - slow as warnings
  mutate(occupation_mode = mode(temp),
         occupation_broad_mode = mode(tempb),
         check = max(temp,na.rm=T),
         checkb = max(tempb,na.rm=T),
         occupation_mode = if_else(is.infinite(check),NA_integer_,occupation_mode),
         occupation_broad_mode = if_else(is.infinite(checkb),NA_integer_,occupation_broad_mode)) %>%
  ungroup() %>%
  select(-temp, -tempb, -check, -checkb)





# Marital status
data <- data %>%
  mutate(marital = case_when(mrcurr == 1 | mrcurr == 2 ~ "partnered",
                             mrcurr == 3 | mrcurr == 4 | mrcurr == 5 ~ "separated",
                             mrcurr == 6 | mrcurr < 1 ~ "single")) # Single means never married and not de facto (includes unclassifieds)

# Retired flag
data <- data %>%
  mutate(retired = case_when(rtcage>0 | rtcomp==1 ~ 1,
                             TRUE ~ 0) )
# Convenience
data <- data %>%
  mutate(one = 1)


#=====================================================================
# Fill in wealth blanks

#-----------------------------------
# Function for filling wealth gaps
fillwealth <- function(DATA,panel,tstep,varlist) {
  ## DATA is data.frame
  ## panel is panel.id for panel()
  ## tstep is time.step for panel()
  ## varlist is char vector of variable names to fill in
  gc()

  # Convert to panel object for leads and lags
  DATA <- panel(as.data.table(DATA), panel.id=panel, time.step=tstep )

  # Leads and lags
  for (var in varlist) {
    DATA[ ,paste0("f1_",var) := fixest::f(get(var), lead=1)]
    DATA[ ,paste0("l1_",var) := fixest::l(get(var), lag=1)]
    DATA[ ,paste0("f2_",var) := fixest::f(get(var), lead=2)]
    DATA[ ,paste0("l2_",var) := fixest::l(get(var), lag=2)]
  }

  # Fill in blanks
  DATA <- as_tibble(DATA)
  for (var in varlist) {
    DATA <- DATA %>%
      mutate("{var}" := case_when( !is.na(get(var)) ~ get(var),
                                      is.na(get(var)) & !is.na(get(paste0("l1_",var))) ~ get(paste0("l1_",var)), # after wealth survey year
                                      is.na(get(var)) & !is.na(get(paste0("f1_",var))) ~ get(paste0("f1_",var)), # before wealth survey year
                                      is.na(get(var)) & !is.na(get(paste0("l2_",var))) ~ get(paste0("l2_",var)), # 2 after wealth survey year
                                      is.na(get(var)) & !is.na(get(paste0("f2_",var))) ~ get(paste0("f2_",var)), # 2 before wealth survey year
                                      TRUE ~ NA_real_  ) )
  }

  # Clean up
  DATA <- DATA %>%
    select( -starts_with(c("l1_","f1_","l2_","f2_")) )

  return(DATA)
}
#-----------------------------------

# Sort
data <- data %>%
  arrange(xwaveid,year)


# Fill wealth gaps
data <- fillwealth(data,c("xwaveid","year"),1,
                c("networth","property_eq","property_val"))

# Top up
topdata <- data %>%
  select(xwaveid,year,topup)


#=====================================================================
# Make unemployment spells
# Note: no employment calendar for 2011 top-up in 2011 -> caune01 = -1 for non-response
# Top-up sample not asked employment calendar p6 HILDA Release 20


# Make long data
spells <- data %>%
  select(xwaveid,year,starts_with("caune")) %>%
  pivot_longer(-c("xwaveid","year"), names_to = "calref", values_to = "unemp") %>%
  mutate(period = as.numeric(sub("caune","",calref))) %>%
  filter(period >= 1 & period <= 36) %>%
  mutate(unemp = if_else(unemp==1,1,0)) %>%
  arrange(xwaveid,year,period)


# Find spells (unit: months) for each person
spells <- spells %>%
  group_by(xwaveid) %>%
  mutate(flags = case_when(dplyr::lag(unemp)==0 &  unemp==1 ~ 1, #new spell
                           dplyr::lead(unemp)==0 & unemp==1 ~ 3, #end spell (order of construction important)
                           dplyr::lag(unemp)==1 &  unemp==1 ~ 2, #continue spell
                           TRUE ~ 0),
         nspells = cumsum(flags==1) ) %>%
  group_by(xwaveid,nspells,unemp) %>%  # group by person, spell and period of unemployment
  mutate(spell = cumsum(unemp),
         length = max(spell)/3,
         length_first = if_else(flags==1,length,0),
         length_end = if_else(flags==3,length,0) ) %>%
  ungroup()

# Collapse -> maximum length spell that started in financial year, or ended
spelldata <- spells %>%
  select(xwaveid,year,length_first,length_end) %>%
  group_by(xwaveid,year) %>%
  mutate(maxspell_unemp = max(na.omit(length_first)),
         maxspell_unemp_end = max(na.omit(length_end))) %>% # note drop NA
  summarise(maxspell_unemp=mean(maxspell_unemp),
            maxspell_unemp_end=mean(maxspell_unemp_end) )

# Remove all 2011 Top-up calendar data (done for spells below too)
spelldata <- spelldata %>%
  full_join(topdata, by=c("xwaveid","year")) %>%
  mutate(maxspell_unemp = if_else(year==2011 & topup == 1 , NA_real_,maxspell_unemp),
         maxspell_unemp_end = if_else(year==2011 & topup == 1, NA_real_,maxspell_unemp_end))

# Combine
data <- data %>%
  full_join(spelldata)

# keep copy
uspells <- spells

# Unemployment spell categorical, did not use
data <- data %>%
  mutate(maxspell_unemp_cat = case_when(maxspell_unemp == 0 ~ 0,
                                  maxspell_unemp > 0 & unemp_pct <= 3 ~ 1,
                                  maxspell_unemp > 3 & unemp_pct <= 12 ~ 2,
                                  maxspell_unemp > 12  ~ 3) )


#=====================================================================
# Rinse and repeat for NILF spells
# Note: no employment calendar for 2011 top-up in 2011

# Make long data
spells <- data %>%
  select(xwaveid,year,starts_with("canlf")) %>%
  pivot_longer(-c("xwaveid","year"), names_to = "calref", values_to = "nilf") %>%
  mutate(period = as.numeric(sub("canlf","",calref))) %>%
  filter(period >= 1 & period <= 36) %>%
  mutate(nilf = if_else(nilf==1,1,0)) %>%
  arrange(xwaveid,year,period)


# Find spells (unit: months) for each person
spells <- spells %>%
  group_by(xwaveid) %>%
  mutate(flags = case_when(dplyr::lag(nilf)==0 &  nilf==1 ~ 1, #new spell
                           dplyr::lead(nilf)==0 & nilf==1 ~ 3, #end spell (order of construction important)
                           dplyr::lag(nilf)==1 &  nilf==1 ~ 2, #continue spell
                           TRUE ~ 0),
         nspells = cumsum(flags==1) ) %>%
  group_by(xwaveid,nspells,nilf) %>%  # group by person, spell and period of nilf
  mutate(spell = cumsum(nilf),
         length = max(spell)/3,
         length_first = if_else(flags==1,length,0),
         length_end = if_else(flags==3,length,0)) %>%
  ungroup()

# Collapse -> maximum length spell that started in financial year, or ended
spelldata <- spells %>%
  select(xwaveid,year,length_first,length_end) %>%
  group_by(xwaveid,year) %>%
  mutate(maxspell_nilf = max(na.omit(length_first)),
         maxspell_nilf_end = max(na.omit(length_end))) %>% # note drop NA
  summarise(maxspell_nilf=mean(maxspell_nilf),
            maxspell_nilf_end=mean(maxspell_nilf_end) )

# Remove all 2011 Top-up calendar data
spelldata <- spelldata %>%
  full_join(topdata, by=c("xwaveid","year")) %>%
  mutate(maxspell_nilf = if_else(year==2011 & topup == 1, NA_real_,maxspell_nilf),
         maxspell_nilf_end = if_else(year==2011 & topup == 1, NA_real_,maxspell_nilf_end))

# Combine
data <- data %>%
  full_join(spelldata)


#=====================================================================
# Merge and save spells

spells <- spells %>%
  select(xwaveid,year,period,nilf) %>%
  full_join(uspells, by=c("xwaveid","year","period"))

# Remove all 2011 Top-up calendar data
spells <- spells %>%
  full_join(topdata, by=c("xwaveid","year")) %>%
  mutate(nspells = as.numeric(nspells)) %>%
  mutate(across(c(nilf,unemp,spell,length,length_first,length_end,flags,nspells) , ~ if_else(year==2011 & topup == 1 , NA_real_,.x) ) )

# Collapse spells to monthly series
spells <- spells %>%
  arrange(xwaveid,year,period) %>%
  group_by(xwaveid,year) %>%
  mutate(month = rep(c(7:12,1:6),each=3)) %>%
  group_by(xwaveid,year,month) %>%
  summarise(unemp_month = mean(unemp),
            nilf_month = mean(nilf),
            topup = mean(topup)) %>%
  ungroup() %>%
  mutate(year_unemp = if_else(month>=7, year-1, year)) %>%
  mutate(date_unemp = make_date(year_unemp, month, 1)) %>%
  rename(year_survey = year)


setwd(hildapath)
save(spells,file=paste0(hildapath,"/DataUnempSpells.RData"))

# Cleanup
rm(spelldata,spells,uspells,topdata)


# Clean calendar trash
data <- data %>%
  select(-starts_with(c("cau","can")))


#=====================================================================
# Save data
setwd(hildapath)
save(data,file=paste0(hildapath,"/DataBase.RData"))


