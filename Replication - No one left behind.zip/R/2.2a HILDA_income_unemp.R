#==============================================================
# HILDA: Income and unemployment regressions (Jacobson, LaLonde and Sullivan (1993); Krolikowski (2017); Lancaster (2021))
# NOTE: Needs database from HILDA_data.R
# Project: Full Employment
# Alex Ballantyne
# 12 May 2022
#==============================================================


# packages ---------------------------------------------------------------------

library(tidyverse)
library(fy)
library(grattantheme)

library(readxl)
library(purrr)
library(lubridate)
library(stats)

library(plm)
library(fixest)
library(data.table) # For flag/L/F lead lag

library(gtools)  #for quantcut



#=====================================================================
# Control

rm(list=ls())

# Define panel index and time vars
panel = c("xwaveid","year")

# Define lead and lag order
leadord = 1
lagord = 5

# Base directory
basepath <- here::here()
setwd(basepath)

# Import utility functions
source("R/utilities.R")

# HILDA data directory (STATA files)
hildapath <- "C:/Users/HILDA"
setwd(hildapath)


#=====================================================================
# Import data

load(paste0(hildapath,"/DataBase.RData"))



#=====================================================================
# Transform data



#---------------------------------------------------------------------
# Make covariates etc

# Some basics
data <- data %>%
  mutate(age2 = age^2,
         female = (sex==2)*1,
         Datsi = (atsi>=2)*1,
         noneng_born = (cob_brief>=3)*1,
         tenure_3yr = (tenure>=3)*1,
         unemp_anycal = (unemp_pct>0)*1,
         nilf_anycal = (nilf_pct>0)*1,
         nilf_50cal = (nilf_pct>50)*1  )


#=====================================================================



# Dummy for first spell of unemployment
data <- data %>%
  arrange(xwaveid,year) %>%
  # Double accumulate to find first instance of unemployment & NILF
  group_by(xwaveid) %>%
  mutate(accum_unemp_anycal = cumsum(unemp_anycal),
         first_unemp_anycal = (cumsum(accum_unemp_anycal)==1)*1  ) %>%
  mutate(accum_nilf_anycal = cumsum(nilf_anycal),
         first_nilf_anycal = (cumsum(accum_nilf_anycal)==1)*1  ) %>%
  # Dummy for ever observed any unemployment
  mutate(have_been_unemp = cumsum(first_unemp_anycal),
         have_been_nilf = cumsum(first_nilf_anycal)) %>%
  ungroup()


# Dummy for reason job change involunatry only
data <- data %>%
  mutate(Dchange_invol = (pjljrea==3 | pjljr==3)*1,
         unemp_mths_invol = Dchange_invol*unemp_mths,
         first_unemp_mths_invol = Dchange_invol*unemp_mths*first_unemp_anycal)


# Make panel lead/lags from utility function
data <- panelleadlags(data,panel,1,1:5,1:5,c("first_unemp_anycal"))

# Set up unemp independent variables and treatment window
data <- data %>%
  # First spell lead/lags, subsequent lead/lags
  mutate(first_window = case_when(first_unemp_anycal==1 | l1_first_unemp_anycal==1 | l2_first_unemp_anycal==1 | l3_first_unemp_anycal==1 | l4_first_unemp_anycal==1 | l5_first_unemp_anycal==1 ~ 1,
                                  TRUE ~ 0 ),
         first_unemp_mths = unemp_mths*first_unemp_anycal,
         # Subsequent unemp spells = those not the first
         subs_unemp_mths = unemp_mths*!first_unemp_anycal,
         # Subs or concurrent NILF = those in window of first unemp
         subs_nilf_mths = nilf_mths*first_window,
         # Concurrent NILFS
         first_unemp_nilf_mths = nilf_mths*first_unemp_anycal,
         # Invol split versions
         first_unemp_mths_invol = Dchange_invol*unemp_mths*first_unemp_anycal,
         first_unemp_mths_othvol = (!Dchange_invol)*unemp_mths*first_unemp_anycal )


# Make panel lead/lags from utility function
# May run out of memory!
varlist = c("nilf_mths","unemp_mths","maxspell_unemp_end","Dchange_invol",
            "first_unemp_mths","subs_unemp_mths","subs_nilf_mths","first_unemp_mths_invol","first_unemp_mths_othvol")
data <- panelleadlags(data,panel,1,1:2,1:5,varlist)


# Make quantile factor by year
p <- c(0.3333,0.6666)
varlist = c("labinc","networth","wage")
namelist = c("Low","Mid","High")
data <- makequants(data,"year",varlist,p)
data <- cleanquants(data,"xwaveid",varlist,namelist,"ter")


#=====================================================================
# Filter data
# OK after finding first spell and making terciles, indep vars?

# ALL: Drop if >= 65 years old or completely retired
# ALL: Drop if unemp_pct==NA
data <- data %>%
  filter(age < 65,
         retired != 1,
         !is.na(unemp_pct)) %>%
  filter(esempst < 2)    # drop self-employed or family worker



#=====================================================================
# Regressions - first unemployment spell

#-----------------------------------------------
# Set up sample


# Include only those employed (>9 months)  and never unemployed
# Include only 5 years after first unemployment spell
# Remove those with NILF > 3 months history

# Make sample by parts
data <- data %>%
  # 1) Those employed > 9 months and absolutely no unemployment history
  mutate(Demp = (emp_pct>=75 & !have_been_unemp)*1) %>%
  # 2) Those within five years since first unemployment
  mutate(Dunemp = case_when(first_window==1 ~ 1,
                               TRUE ~ 0) ) %>%
  group_by(xwaveid) %>%
  # Flag those beyond first 5 years - important!
  mutate(Dover5y = cumsum(Dunemp),
         Dover5y = cumsum(Dover5y),
         Dover5y = (Dover5y>21)*1 ) %>%
  # Flag those with NILF history > 3mths & NOT educ in a year (unless nilf starts after first unemployment spell)
  mutate(prior_nilf = (nilf_pct>25 & fteduc_pct<25)*1,
         prior_nilf = cumsum(prior_nilf), # roll forward
         prior_nilf = (prior_nilf>0 & !Dunemp)*1, # prior nilf, but not if in window
         prior_nilf = cumsum(prior_nilf) ) %>%  # roll forward
  # Average annual NILF prior to t=0 unemp
  mutate(prior_nilf_mean = cummean(nilf_mths),
         prior_nilf_mean_tm1 = prior_nilf_mean*(f1_first_unemp_anycal==1),
         prior_nilf_mean_tm1 = cumsum(prior_nilf_mean_tm1),
         prior_nilf_mean = if_else(Dunemp==1,prior_nilf_mean_tm1,prior_nilf_mean) ) %>%
  ungroup() %>%
  # Sample flag
  mutate(Dsamp = (Demp | Dunemp) & !prior_nilf & !Dover5y)



# Reg data without outliers, filtered, only variables needed
firstdata <- data %>%
  filter(Dsamp==TRUE) %>%  # Special sample
  filter( !(labinc==0 & emp_pct>0) ) %>%   # drop zero lab income but employed
  filter( !(labinc>0 & (unemp_pct==100 | nilf_pct==100 | emp_pct==0) ) )  %>%   # drop pos lab income but unemployed or nilf
  select(xwaveid, year, labinc, age, age2, age_group, educ_det,
         maxspell_unemp_end, maxspell_nilf_end, unemp_mths, unemp_mths_invol, nilf_mths, subs_nilf_mths, subs_unemp_mths, first_unemp_mths, first_unemp_mths_invol, first_unemp_mths_othvol,
         have_been_unemp, have_been_nilf, prior_nilf, prior_nilf_mean,
         starts_with(c("f1","f2","l1","l2","l3","l4","l5")),
         educ, female, Datsi, noneng_born, labinc_ter, networth_ter, wage_ter, occupation_broad_mode)

# Finalise sample
firstdata <- firstdata[complete.cases(firstdata),]


# Labour income (Left Hand Side) deflated using the growth in sample average income
# Base year 2007, every year has same average
# If raw levels, can only use observations for 2007 for rescaling coefficients since base year for fixed effects
# Rescaling using raw instead of _lhs variable will change the magnitude, but not the profile
firstdata <- firstdata %>%
  group_by(year) %>%
  mutate(labinc_year = mean(labinc)) %>%
  ungroup() %>%
  mutate(labinc_year = labinc_year/min(labinc_year)) %>%
  mutate(labinc_lhs = labinc/labinc_year)



# If using IHS transformation, see Bellemare 2020 Elasticities and the IHS Transformation
# elas = beta*x equation (7) -> where x is total sample mean of covariate
# Not great using IHS or log because it is now a linear relationship not binary regressor -> unemp linear in income, not log-income



#=====================================================================
# Regressions
# Need to account for? i) people employed in year but reporting zero lab income -> drop zero income obs?
#                     ii) people unemp or nilf all year but reporting positive lab income -> drop?


#-----------------------------------------------
# REGS

# PREFERRED - First Spell
# Unemployment months
lab_first <- feols(labinc ~
                    f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                    subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                    subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                  have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                  data=firstdata, panel.id=panel)
summary(lab_first, cluster = c("xwaveid","year"))


# Robustness versions:
# 1) without leads: OK
# 2) without partial effect controls: OK
# 3) Parallel trends graph: ~OK
# 4) Sun Abraham 2020: OK
# 5) invol / othvol: same same

lab_total <- feols(labinc ~
                     f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                       have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)   | xwaveid + year,
                   data=firstdata, panel.id=panel)

lab_noleads <- feols(labinc ~
                     first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                     subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                       subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                       have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)   | xwaveid + year,
                   data=firstdata, panel.id=panel)

# Involuntary attempt
lab_invol <- feols(labinc ~
                     f2_first_unemp_mths_invol + f1_first_unemp_mths_invol + first_unemp_mths_invol + l1_first_unemp_mths_invol + l2_first_unemp_mths_invol + l3_first_unemp_mths_invol + l4_first_unemp_mths_invol + l5_first_unemp_mths_invol +
                     f2_first_unemp_mths_othvol + f1_first_unemp_mths_othvol + first_unemp_mths_othvol + l1_first_unemp_mths_othvol + l2_first_unemp_mths_othvol + l3_first_unemp_mths_othvol + l4_first_unemp_mths_othvol + l5_first_unemp_mths_othvol +
                     subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                     subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                     have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                   data=firstdata, panel.id=panel)
summary(lab_invol, cluster = c("xwaveid","year"))




# SEX
lab_first_sex <- feols(labinc ~
                         #f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                         #subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                         f2_unemp_mths + f1_unemp_mths + unemp_mths + l1_unemp_mths + l2_unemp_mths + l3_unemp_mths + l4_unemp_mths + l5_unemp_mths +
                         subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                         have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                   data=firstdata, panel.id=panel, split = ~female)

# EDUC
lab_first_educ <- feols(labinc ~
                          #f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                          #subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                          f2_unemp_mths + f1_unemp_mths + unemp_mths + l1_unemp_mths + l2_unemp_mths + l3_unemp_mths + l4_unemp_mths + l5_unemp_mths +
                          subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                          have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                       data=firstdata, panel.id=panel, split = ~educ)

# NONENG - too few obs
lab_first_cob <- feols(labinc ~
                         #f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                         #subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                         f2_unemp_mths + f1_unemp_mths + unemp_mths + l1_unemp_mths + l2_unemp_mths + l3_unemp_mths + l4_unemp_mths + l5_unemp_mths +
                         subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                         have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                        data=firstdata, panel.id=panel, split = ~noneng_born)

# AGE
lab_first_age <- feols(labinc ~
                         #f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                         #subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                         f2_unemp_mths + f1_unemp_mths + unemp_mths + l1_unemp_mths + l2_unemp_mths + l3_unemp_mths + l4_unemp_mths + l5_unemp_mths +
                         subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                         have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                       data=firstdata, panel.id=panel, split = ~age_group)


# NETWORTH TER
lab_first_networth <- feols(labinc ~
                              #f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                              #subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                              f2_unemp_mths + f1_unemp_mths + unemp_mths + l1_unemp_mths + l2_unemp_mths + l3_unemp_mths + l4_unemp_mths + l5_unemp_mths +
                              subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                              have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                       data=firstdata, panel.id=panel, split = ~networth_ter)


# INCOME TER - ENDOG!!! and too few obs in first tercile
lab_first_labinc <- feols(labinc ~
                            #f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                            #subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                            f2_unemp_mths + f1_unemp_mths + unemp_mths + l1_unemp_mths + l2_unemp_mths + l3_unemp_mths + l4_unemp_mths + l5_unemp_mths +
                            subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                            have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                            data=firstdata, panel.id=panel, split = ~labinc_ter)

# WAGE TER
lab_first_wage <- feols(labinc ~
                          #f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                          #subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                          f2_unemp_mths + f1_unemp_mths + unemp_mths + l1_unemp_mths + l2_unemp_mths + l3_unemp_mths + l4_unemp_mths + l5_unemp_mths +
                          subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                          have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                            data=firstdata, panel.id=panel, split = ~wage_ter)

# OCCUP TER
lab_first_occupation <- feols(labinc ~
                                #f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                                #subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                                f2_unemp_mths + f1_unemp_mths + unemp_mths + l1_unemp_mths + l2_unemp_mths + l3_unemp_mths + l4_unemp_mths + l5_unemp_mths +
                                subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                                have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)  | xwaveid + year,
                        data=firstdata, panel.id=panel, split = ~occupation_broad_mode)

#-------------------------------------------------------------------------
# TEST USING SPELL LENGTH 
#
#
spelldata <- firstdata %>%
  filter(maxspell_unemp_end <= 50) %>%   # drop outliers for spells
  filter(maxspell_nilf_end <= 100)  # drop outliers for spells
spelldata <- spelldata[complete.cases(spelldata),]

lab_spell <- feols(labinc ~
                     f2_first_unemp_mths + f1_first_unemp_mths + first_unemp_mths + l1_first_unemp_mths + l2_first_unemp_mths + l3_first_unemp_mths + l4_first_unemp_mths + l5_first_unemp_mths +
                     subs_unemp_mths + l1_subs_unemp_mths + l2_subs_unemp_mths + l3_subs_unemp_mths + l4_subs_unemp_mths +
                     subs_nilf_mths + l1_subs_nilf_mths + l2_subs_nilf_mths + l3_subs_nilf_mths + l4_subs_nilf_mths + l5_subs_nilf_mths +
                     f2_maxspell_unemp_end + f1_maxspell_unemp_end + maxspell_unemp_end + l1_maxspell_unemp_end + l2_maxspell_unemp_end + l3_maxspell_unemp_end + l4_maxspell_unemp_end + l5_maxspell_unemp_end +
                     have_been_nilf + age*factor(educ_det) + age2*factor(educ_det)   | xwaveid + year,
                   data=spelldata, panel.id=panel)
summary(lab_spell)


#-------------------------------------------------------------------------
# ROBUSTNESS USING Sun & Abraham 2020
# https://www.sciencedirect.com/science/article/abs/pii/S030440762030378X
#

# Time to treatment for Sun Abraham 2020
# Non NILF dataset
# https://lost-stats.github.io/Model_Estimation/Research_Design/event_study.html
sunabdata <- data %>%
  group_by(xwaveid) %>%
  mutate(sunab_prior_nilf = (nilf_pct>50)*1,
         sunab_prior_nilf = cumsum(sunab_prior_nilf),
         sunab_prior_nilf = (sunab_prior_nilf>0)*1) %>%
  filter( sunab_prior_nilf==0 ) %>% # Alternative !(sunab_prior_nilf==1 & year < treatment)
  mutate(treatment = if_else(first_unemp_mths>0,year,0),
         treatment = max(treatment) ) %>% # define for indiv
  mutate(time_to_treat = if_else(treatment>0,year-treatment,0),
         year_treated = if_else(treatment==0,10000,treatment)) %>%
  ungroup()

# SunAB uses non NILF dataset
lab_sunab <- feols(labinc ~
                     sunab(year_treated, year) +
                     i(time_to_treat,subs_unemp_mths) +
                     i(time_to_treat,subs_nilf_mths) +
                     prior_nilf_mean + age*factor(educ_det) + age2*factor(educ_det)   | xwaveid + year,
                   data=sunabdata, panel.id=panel)
iplot_lab_sunab <- iplot(lab_sunab)

lab_sunab_total <- feols(labinc ~
                           sunab(year_treated, year) +
                           prior_nilf_mean + age*factor(educ_det) + age2*factor(educ_det)   | xwaveid + year,
                         data=sunabdata, panel.id=panel)
iplot_lab_sunab_total <- iplot(lab_sunab_total)




#=====================================================================
# Make latex table


varnames <- c('f2_first_unemp_mths' = "First: -2",
              'f1_first_unemp_mths' = "First: -1",
              'first_unemp_mths' = "First: 0",
              'l1_first_unemp_mths' = "First: 1",
              'l2_first_unemp_mths' = "First: 2",
              'l3_first_unemp_mths' = "First: 3",
              'l4_first_unemp_mths' = "First: 4",
              'l5_first_unemp_mths' = "First: 5",
              'subs_unemp_mths' = "Subsequent: 0",
              'l1_subs_unemp_mths' = "Subsequent: 1",
              'l2_subs_unemp_mths' = "Subsequent: 2",
              'l3_subs_unemp_mths' = "Subsequent: 3",
              'l4_subs_unemp_mths' = "Subsequent: 4",
              'subs_nilf_mths' = "NILF: 0",
              'l1_subs_nilf_mths' = "NILF: 1",
              'l2_subs_nilf_mths' = "NILF: 2",
              'l3_subs_nilf_mths' = "NILF: 3",
              'l4_subs_nilf_mths' = "NILF: 4",
              'l5_subs_nilf_mths' = "NILF: 5",
              'xwaveid' = "Individual",
              'year' = "Year",
              'labinc' = "Labour income")

# Setting a dictionary
setFixest_dict(varnames)


# REQUIRES MANUAL ADJUSTMENT EX POST - particularly adding in tabs (&) between ses to make new column
etable(lab_first, lab_total,
       cluster = c("xwaveid","year"),
       keep = varnames,
       tex = TRUE,
       file = paste0(basepath,"Output/income_unemp_regs.tex"),
       se.below = F,
       style.tex = style.tex(var.title = "\\midrule \\emph{Unemployment and NILF spells}"),
       replace=T)



##########################################
## Save results

save(list = c(ls(pattern="lab_fir*"),"lab_spell","lab_invol"), firstdata, spelldata, iplot_lab_sunab, lab_sunab, file=paste0(hildapath,"/Income_Regs_First.RData"))


