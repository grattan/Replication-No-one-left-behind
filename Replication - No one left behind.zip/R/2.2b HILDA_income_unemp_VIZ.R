#==============================================================
# HILDA: Viz for Income and unemployment regressions
# NOTE: Needs database from HILDA_income_unemp.R
# Project: Full Employment
# Alex Ballantyne
# 12 May 2022
#==============================================================


# packages ---------------------------------------------------------------------

library(tidyverse)
library(fy)
library(grattantheme)

library(readxl)
library(purrr)
library(lubridate)
library(stats)

library(fixest)

library(car)

library(scales)

#=====================================================================
# Control

rm(list=ls())


# Which coefficients to plot
selection = c("f2_first_unemp_mths","f1_first_unemp_mths","first_unemp_mths","l1_first_unemp_mths","l2_first_unemp_mths","l3_first_unemp_mths","l4_first_unemp_mths","l5_first_unemp_mths")
other_selection <- c("subs_unemp_mths","l1_subs_unemp_mths","l2_subs_unemp_mths","l3_subs_unemp_mths","l4_subs_unemp_mths",
                     "subs_nilf_mths","l1_subs_nilf_mths","l2_subs_nilf_mths","l3_subs_nilf_mths","l4_subs_nilf_mths","l5_subs_nilf_mths")
spells_selection <- c("f2_maxspell_unemp_end","f1_maxspell_unemp_end","maxspell_unemp_end","l1_maxspell_unemp_end","l2_maxspell_unemp_end","l3_maxspell_unemp_end","l4_maxspell_unemp_end","l5_maxspell_unemp_end")
invol_selection <- c("f2_first_unemp_mths_invol","f1_first_unemp_mths_invol","first_unemp_mths_invol","l1_first_unemp_mths_invol","l2_first_unemp_mths_invol","l3_first_unemp_mths_invol","l4_first_unemp_mths_invol","l5_first_unemp_mths_invol",
                     "f2_first_unemp_mths_othvol","f1_first_unemp_mths_othvol","first_unemp_mths_othvol","l1_first_unemp_mths_othvol","l2_first_unemp_mths_othvol","l3_first_unemp_mths_othvol","l4_first_unemp_mths_othvol","l5_first_unemp_mths_othvol")
unemp_selection <- c("f2_unemp_mths","f1_unemp_mths","unemp_mths","l1_unemp_mths","l2_unemp_mths","l3_unemp_mths","l4_unemp_mths","l5_unemp_mths")

# How many months of unemployment to set scale (avg ~5 months)
scale = 3

# Base year from fixef(lab_first)
baseyear = 2007


# Define panel index and time vars
panel = c("xwaveid","year")

# Base directory
basepath <- here::here()
setwd(basepath)

# Import utility functions
source("R/utilities.R")

# HILDA data directory (STATA files)
hildapath <- "C:/Users/HILDA"
setwd(hildapath)



#=====================================================================
# Import data

load(paste0(hildapath,"/Income_Regs_First.RData"))


#=====================================================================
# Transform data

#---------------------------------------------------------------------
# Find average first_unemp_mths
avg_mths = mean(firstdata$first_unemp_mths[firstdata$first_unemp_mths>0])
avg_mths_all = mean(firstdata$first_unemp_mths)


#---------------------------------------------------------------------
# Pull wanted coefficients,

# collect regressions
reg_list <- as.list(ls(pattern="lab_first"))
reg_list_groups <- reg_list[!(reg_list %in% c("lab_first"))]


# Separate split regressions
for (reg in reg_list_groups) {
  for(split in names(get(reg))) {
    assign(paste0(reg,split), get(reg)[sample=split])
  }
}

# collect regressions anew
reg_list_new <-  as.list(ls(pattern="lab_first"))
reg_list_new <- reg_list_new[!(reg_list_new %in% reg_list_groups)]
reg_list_groups <- reg_list_new[!(reg_list_new %in% c("lab_first"))]
reg_list_base <- reg_list_new[(reg_list_new %in% c("lab_first"))]


group_regs = map(.x=reg_list_groups, .f=~get(.x)) %>%
  setNames(reg_list_groups)

base_regs = map(.x=reg_list_base, .f=~get(.x)) %>%
  setNames(reg_list_base)

#---------------------------------------------------------------------
# Pull coeffs - GROUP REGS

# Pre-treatment income
labinc_pretreatment <- list()
which_pre_treat <- firstdata$f1_first_unemp_mths>0
# Transform to % change using avg pre-treatment labinc
for (reg in names(group_regs)) {
  # Get observation selection
  if (length(group_regs[[reg]]$obs_selection)==0) {
    sample = 1:dim(firstdata)[1]
  } else {
    sample = group_regs[[reg]]$obs_selection[[1]]
  }
  # Average labinc_lhs from pre-treatment (f1>0), needs labinc_lhs to avoid using only baseyear obs as need to scale for 2007 base
  labinc_pretreatment[[reg]] <-  sum(firstdata$labinc_lhs[sample]*which_pre_treat[sample]) / sum(which_pre_treat[sample])
}
# Pull coeffs
coeffs_unemp_raw <- map(.x=group_regs, .f=~.x$coefficients[names(.x$coefficients) %in% unemp_selection])
# Transform to % change using avg pre-treatment labinc
coeffs_unemp <- map2(.x=coeffs_unemp_raw, .y=labinc_pretreatment, .f=~((.x*scale)/.y*100))
# Pull SEs, feols default se() is clustered by only one FE
ses_unemp_raw <- map(.x=group_regs, .f=~se(.x, cluster = c("xwaveid","year"))[names(.x$coefficients) %in% unemp_selection])
# Make high low error bars
error_low <- map2(.x=ses_unemp_raw, .y=coeffs_unemp_raw, .f=~.y-2*.x)
error_low <- map2(.x=error_low, .y=labinc_pretreatment, .f=~((.x*scale)/.y*100))
error_high <- map2(.x=ses_unemp_raw, .y=coeffs_unemp_raw, .f=~.y+2*.x)
error_high <- map2(.x=error_high, .y=labinc_pretreatment, .f=~((.x*scale)/.y*100))


#---------------------------------------------------------------------
# BASE regression with secondary spells and nilfs

# Pre-treatment income
labinc_pretreatment <- list()
which_pre_treat <- firstdata$f1_first_unemp_mths>0
# Transform to % change using avg pre-treatment labinc
for (reg in names(base_regs)) {
  # Get observation selection
  if (length(base_regs[[reg]]$obs_selection)==0) {
    sample = 1:dim(firstdata)[1]
  } else {
    sample = base_regs[[reg]]$obs_selection[[1]]
  }
  # Average labinc_lhs from pre-treatment (f1>0), needs labinc_lhs to avoid using only baseyear obs as need to scale for 2007 base
  labinc_pretreatment[[reg]] <-  sum(firstdata$labinc_lhs[sample]*which_pre_treat[sample]) / sum(which_pre_treat[sample])
}
# Pull coeffs
other_coeffs_unemp_raw <- map(.x=base_regs, .f=~.x$coefficients[names(.x$coefficients) %in% c(selection,other_selection)])
# Transform to % change using avg pre-treatment labinc
other_coeffs_unemp <- map2(.x=other_coeffs_unemp_raw, .y=labinc_pretreatment, .f=~((.x*scale)/.y*100))
# Pull SEs, feols default se() is clustered by only one FE
other_ses_unemp_raw <- map(.x=base_regs, .f=~se(.x, cluster = c("xwaveid","year"))[names(.x$coefficients) %in% c(selection,other_selection)])
# Make high low error bars
other_error_low <- map2(.x=other_ses_unemp_raw, .y=other_coeffs_unemp_raw, .f=~.y-2*.x)
other_error_low <- map2(.x=other_error_low, .y=labinc_pretreatment, .f=~((.x*scale)/.y*100))
other_error_high <- map2(.x=other_ses_unemp_raw, .y=other_coeffs_unemp_raw, .f=~.y+2*.x)
other_error_high <- map2(.x=other_error_high, .y=labinc_pretreatment, .f=~((.x*scale)/.y*100))

#---------------------------------------------------------------------

#---------------------------------------------------------------------
# Involunary split
# Find t-1 pre-treatment
invol_which_pre_treat <- firstdata$f1_first_unemp_mths_invol>0
othvol_which_pre_treat <- firstdata$f1_first_unemp_mths_othvol>0
# Labour income at t-1 pre-treatment
invol_labinc_pretreatment <-  sum(firstdata$labinc_lhs*invol_which_pre_treat) / sum(invol_which_pre_treat)
othvol_labinc_pretreatment <-  sum(firstdata$labinc_lhs*othvol_which_pre_treat) / sum(othvol_which_pre_treat)
invol_which_invol <- regexpr("invol",invol_selection)>0
# Pull coeffs
invol_coeffs_unemp_raw <- lab_invol$coefficients[names(lab_invol$coefficients) %in% c(invol_selection)]
# Transform to % change using avg pre-treatment labinc
invol_coeffs_unemp <- c((invol_coeffs_unemp_raw[invol_which_invol]*scale)/invol_labinc_pretreatment*100,
                        (invol_coeffs_unemp_raw[!invol_which_invol]*scale)/othvol_labinc_pretreatment*100)

#---------------------------------------------------------------------







#=====================================================================
# Viz

# Compile viz data
lowdata <- data.frame(matrix(unlist(error_low), ncol=length(coeffs_unemp), byrow=FALSE)) %>%
  setNames(reg_list_groups) %>%
  mutate(time = -2:5) %>%
  pivot_longer(-time, values_to = "error_low")

highdata <- data.frame(matrix(unlist(error_high), ncol=length(coeffs_unemp), byrow=FALSE)) %>%
  setNames(reg_list_groups) %>%
  mutate(time = -2:5) %>%
  pivot_longer(-time, values_to = "error_high")

vizdata = data.frame(matrix(unlist(coeffs_unemp), ncol=length(coeffs_unemp), byrow=FALSE)) %>%
  setNames(reg_list_groups) %>%
  mutate(time = -2:5) %>%
  pivot_longer(-time) %>%
  full_join(lowdata) %>%
  full_join(highdata) %>%
  # Remove non-viz regs
  filter(!str_detect(name,"atsi") & !str_detect(name,"cob") & !str_detect(name,"labinc")) %>%
  mutate(cat = case_when(str_detect(name,"sex") ~ "Gender",
                         str_detect(name,"atsi") ~ "ATSI",
                         str_detect(name,"cob") ~ "Foreign born",
                         str_detect(name,"educ") ~ "Education",
                         str_detect(name,"networth") ~ "Net worth",
                         str_detect(name,"wage") ~ "Wage",
                         str_detect(name,"age") ~ "Age",
                         str_detect(name,"labinc") ~ "Labour income",
                         str_detect(name,"occupation") ~ "Broad occupation",
                         str_detect(name,"total") ~ "Total effect")) %>%
  mutate(lab = case_when(name=="lab_first_total" ~ "Total effect",
                         name=="lab_first_sex0" ~ "Male",
                         name=="lab_first_sex1" ~ "Female",
                         name=="lab_first_atsi0" ~ "Non-ATSI",
                         name=="lab_first_atsi1" ~ "ATSI",
                         name=="lab_first_cob0" ~ "English country born",
                         name=="lab_first_cob1" ~ "Non-english born",
                         name=="lab_first_educ1" ~ "School",
                         name=="lab_first_educ2" ~ "Tafe",
                         name=="lab_first_educ3" ~ "University",
                         name=="lab_first_networthLow" ~ "Low",
                         name=="lab_first_networthMid" ~ "Mid",
                         name=="lab_first_networthHigh" ~ "High",
                         name=="lab_first_wageLow" ~ "Low",
                         name=="lab_first_wageMid" ~ "Mid",
                         name=="lab_first_wageHigh" ~ "High",
                         name=="lab_first_age18-34" ~ "18-34",
                         name=="lab_first_age35-54" ~ "35-54",
                         name=="lab_first_age55-64" ~ "55-64",
                         name=="lab_first_labincLow" ~ "Low",
                          name=="lab_first_labincMid" ~ "Mid",
                          name=="lab_first_labincHigh" ~ "High",
                         name=="lab_first_occupation1" ~ "Non-routine cognitive",
                         name=="lab_first_occupation2" ~ "Non-routine manual",
                         name=="lab_first_occupation3" ~ "Routine cognitive",
                         name=="lab_first_occupation4" ~ "Routine manual" ) ) %>%
  mutate(facet = factor(cat, levels = c("Education",
                                        "Gender",
                                        "ATSI",
                                        "Age",
                                        "Net worth",
                                        "Labour income",
                                        "Wage",
                                        "Broad occupation",
                                        "Foreign born",
                                        "Total effect"), ordered=T)) %>%
  group_by(facet) %>%
  mutate(col = as.factor(as.integer(factor(name)))) %>%
  ungroup()


#=====================================================================
# Multipanel



# multi
viz_unemp_first_multi <- vizdata %>%
  filter(cat== "Age" | cat== "Gender" | cat== "Education" | cat== "Net worth" | cat== "Wage" | cat== "Broad occupation" ) %>%
  ggplot(aes(x = time, y = value, col = col)) +
  geom_line() +
  geom_ribbon(aes(ymin=error_low, ymax=error_high, fill=col), alpha = 0.20, colour = NA ) +
  grattan_colour_manual(4) +
  grattan_fill_manual(4) +
  facet_wrap(vars(facet), nrow=3) +
  grattan_y_continuous(labels = function(x) paste0(x, "%"), limits = c(-scale/12*150,scale/12*50)) +
  scale_x_continuous(name = "Years since unemployment", expand = expansion(mult=c(0.05,0.2)),
                     limits = c(-2.1,5.1), breaks = -2:5 ) +
  theme_grattan() +
  grattan_label(data = ~filter(.,time == 5),
                      aes(label = lab), label.size = NA) +
  labs(title = "The effect of unemployment on labour income is similar across households",
       subtitle = paste0("Percentage reduction in labour income due to ",scale, " months of unemployment"),
       caption = paste0("Notes: Estimates are shown as percentage changes relative to average labour income in the year prior to unemployment. ",
                        "They are derived from a regression of labour income on periods of unemployment and NILF, controlling for factors that affect income over the life cycle. ",
                        "For details, see https://grattan.edu.au/report/no-one-left-behind-why-australia-should-lock-in-full-employment/. ",
                        "Shaded regions are two-standard-error bands. ",
                        "Source: Grattan analysis of HILDA Release 20.0") )

viz_unemp_first_multi





#=====================================================================
# Base partial effect model

# Compile ex data
exdata = data.frame(value=other_coeffs_unemp$lab_first) %>%
  mutate(time = c(-2:5,0:4,0:5)) %>%
  mutate(var = c(rep("First unemployment spell",8),rep("Subsequent unemployment spells",5),rep("Subsequent NILF spells",6))) %>%
  mutate(error_low = other_error_low$lab_first,
         error_high = other_error_high$lab_first) %>%
  mutate(facet = factor(var, levels = c("First unemployment spell",
                                        "Subsequent unemployment spells",
                                        "Subsequent NILF spells"), ordered=T))



# extras, partial effects
viz_unemp_partial <- exdata %>%
  ggplot(aes(x = time, y = value, col = var)) +
  geom_line() +
  geom_ribbon(aes(ymin=error_low, ymax=error_high, fill=var), alpha = 0.20, colour = NA ) +
  grattan_colour_manual(3) +
  grattan_fill_manual(3) +
  facet_wrap(vars(facet), nrow=3) +
  grattan_y_continuous(labels = function(x) paste0(x, "%"), limits = c(-scale/12*150,scale/12*50)) +
  scale_x_continuous(name = "Years since spell began", expand = expansion(mult=c(0.05,0.2)),
                     limits = c(-2.1,5.1), breaks = -2:5 ) +
  theme_grattan() +
  labs(title = "The first period of unemployment casts a long shadow in income",
       subtitle = paste0("Percentage reduction in labour income due to ",scale, " months of unemployment or NILF"),
       caption = paste0("Notes: Estimates are shown as percentage changes relative to average labour income in the year prior to first unemployment. ",
                        "They are derived from a regression of labour income on periods of unemployment and NILF, controlling for factors that affect income over the life cycle. ",
                        "For details, see https://grattan.edu.au/report/no-one-left-behind-why-australia-should-lock-in-full-employment/. ",
                        "Shaded regions are two-standard-error bands. ",
                        "Source: Grattan analysis of HILDA Release 20.0") )

viz_unemp_partial


#=====================================================================
# Viz - base first spell only

# Baseline
viz_unemp_first_base <- exdata %>%
  filter(var == "First unemployment spell") %>%
  ggplot(aes(x = time, y = value)) +
  geom_line() +
  geom_ribbon(aes(ymin=error_low, ymax=error_high), alpha = 0.15 ) +
  grattan_colour_manual(1) +
  grattan_fill_manual(1) +
  grattan_y_continuous(labels = function(x) paste0(x, "%"), limits = c(-scale/12*150,scale/12*50)) +
  scale_x_continuous(name = "Years since unemployment", expand = expansion(mult=c(0.05,0.05)),
                     limits = c(-2.1,5.1), breaks = -2:5 ) +
  theme_grattan() +
  labs(title = "Income stays permanently lower after the first period of unemployment",
       subtitle = paste0("Percentage reduction in labour income due to three months of unemployment"),
       caption = paste0("Notes: Estimates are shown as percentage changes relative to average labour income in the year before unemployment. ",
                        "They are derived from a regression of labour income on periods of unemployment and NILF, controlling for factors that affect income over the life cycle. ",
                        "Shaded regions are two-standard-error bands. ",
                        "For details, see https://grattan.edu.au/report/no-one-left-behind-why-australia-should-lock-in-full-employment/. ",
                        "Source: Grattan analysis of HILDA Release 20.0") )

viz_unemp_first_base




#=====================================================================
# Save charts -----



#=====================================================================
# Postscript stats

print(paste0("Basic model at 5 years decline (per cent): ",other_coeffs_unemp[["lab_first"]]["l5_first_unemp_mths"]))

print(paste0("Total effect of first spell over 5 years (per cent): ",sum(other_coeffs_unemp$lab_first[3:8])))

print(paste0("The sample average length of first unemployment spells is ",round(mean(firstdata$first_unemp_mths[firstdata$first_unemp_mths>0]),1),
             " months (from ", table(firstdata$first_unemp_mths>0)[2],
             " observations), subsequent unemployment spells is ", round(mean(firstdata$subs_unemp_mths[firstdata$subs_unemp_mths>0]),1),
             " months (from ", table(firstdata$subs_unemp_mths>0)[2],
             " observations), and subsequent NILF spells is ", round(mean(firstdata$subs_nilf_mths[firstdata$subs_nilf_mths>0]),1),
             " months (from ", table(firstdata$subs_nilf_mths>0)[2], " observations)."
             ))

