#==============================================================
# HILDA: Pull out some basic unemployment features caross the distribution
# NOTE: Needs database from HILDA_data.R
# Project: Full Employment
# Alex Ballantyne
# 21 January 2021
#==============================================================


# packages ---------------------------------------------------------------------

library(tidyverse)
library(fy)
library(grattantheme)

library(readxl)
library(purrr)
library(lubridate)
library(stats)

library(gtools)  #for quantcut

library(srvyr) # Survey package for dplyr

library(patchwork) #Annoying panels

#=====================================================================
# Control

rm(list=ls())

# Define panel index and time vars
panel = c("xwaveid","year")

# Base directory
basepath <- here::here()
setwd(basepath)

# Import utility functions
source("R/utilities.R")


# HILDA data directory (STATA files)
hildapath <- "C:/Users/HILDA"
setwd(hildapath)



#=====================================================================
# Import data

load(paste0(hildapath,"/DataBase.RData"))


#=====================================================================
# Transform data


#---------------------------------------------------------------------
# Make covariates etc

# Some basics
data <- data %>%
  mutate(age2 = age^2,
         atsi = (atsi>=2)*1,
         unemp_anycal = (unemp_pct>0)*1,
         nilf_50cal = (nilf_pct>50)*1  )


# Make quantile factor by year
p <- c(0.3333,0.6666)
varlist = c("labinc","nonlabinc","networth","wage")
namelist = c("Low","Mid","High")
data <- makequants(data,"year",varlist,p)
data <- cleanquants(data,"xwaveid",varlist,namelist,"ter")


#=====================================================================
# Filter data

# ALL: Drop if >= 65 years old or completely retired
data <- data %>%
  filter(age < 65,
         retired != 1)


# Relabel some things
data <- data %>%
  mutate(educ = case_when(educ==1 ~ "High school",
                          educ==2 ~ "Diploma",
                          educ==3 ~ "University")) %>%
  mutate(sex = case_when(sex==1 ~ "Male",
                         sex==2 ~ "Female")) %>%
  mutate(atsi = case_when(atsi==1 ~ "ATSI",
                          atsi==0 ~ "Non-ATSI")) %>%
  mutate(industry_broad_mode = case_when(industry_broad_mode==1 ~ "Production and amenities",
                                         industry_broad_mode==2 ~ "Trade and logistics",
                                         industry_broad_mode==3 ~ "Business services",
                                         industry_broad_mode==4 ~ "Household services")) %>%
  mutate(occupation_broad_mode = case_when(occupation_broad_mode==1 ~ "Non-routine cognitive",
                                           occupation_broad_mode==2 ~ "Non-routine manual",
                                           occupation_broad_mode==3 ~ "Routine cognitive",
                                           occupation_broad_mode==4 ~ "Routine manual"))


#=====================================================================
# Unemployment incidence by cuts

# Weighted by responding person weight hhwtrp
# Weight sum should be 15.0 million in wave 1, but is short since culled under 18 year olds in DataBase.RData?
# Need to exclude top-up for 2011 since no employment calendar in this year | excluding 2011 top up weight: hhwtrpm
data <- data %>%
  mutate(new_weight = if_else(year==2011,hhwtrpm,hhwtrp))

# srvyr package very slow: weighted.mean identical point estimates but no standard errors
# data <- data %>% as_survey(weights = c(new_weight))
# summarise(unemp_pct = survey_mean(unemp_pct,na.rm=T)) %>%


#-----------------------------------
# Function for making unemployment rate by year and group
make_group_var_year <- function(DATA,var,group,label,weight) {
  out <- DATA %>%
    group_by(year,get(group)) %>%
    summarise("{var}" := weighted.mean(get(var),get(weight),na.rm=T)) %>%
    rename(group = 'get(group)') %>%
    filter(!is.na(group)) %>%
    mutate(cat = paste0(label)) %>%
    ungroup()

  return(out)
}
#-----------------------------------

#-----------------------------------
# Function for making unemployment rate by group ONLY
make_group_var_pool <- function(DATA,var,group,label,weight) {
  out <- DATA %>%
    group_by(get(group)) %>%
    summarise("{var}" := weighted.mean(get(var),get(weight),na.rm=T)) %>%
    rename(group = 'get(group)') %>%
    filter(!is.na(group)) %>%
    mutate(cat = paste0(label)) %>%
    ungroup()

  return(out)
}
#-----------------------------------


# Education
unemp_pct_educ <- make_group_var_year(data,"unemp_pct","educ","Education","new_weight")

# Sex
unemp_pct_sex <- make_group_var_year(data,"unemp_pct","sex","Gender","new_weight")

# ATSI
unemp_pct_atsi <- make_group_var_year(data,"unemp_pct","atsi","ATSI","new_weight")

# Age
unemp_pct_age <- make_group_var_year(data,"unemp_pct","age_group","Age","new_weight")

# Wealth
unemp_pct_networth <- make_group_var_year(data,"unemp_pct","networth_ter","Net worth","new_weight")

# Lab income - super endogenous
#unemp_pct_labinc <- make_group_var_year(data,"unemp_pct","labinc_ter","Labour income","new_weight")

# NONLab income
unemp_pct_nonlabinc <- make_group_var_year(data,"unemp_pct","nonlabinc_ter","Non-labour income","new_weight")

# Wage
unemp_pct_wage <- make_group_var_year(data,"unemp_pct","wage_ter","Wage","new_weight")

# Industry (modal)
unemp_pct_industry <- make_group_var_year(data,"unemp_pct","industry_broad_mode","Broad industry","new_weight")

# Occupation (modal)
unemp_pct_occupation <- make_group_var_year(data,"unemp_pct","occupation_broad_mode","Broad occupation","new_weight")




# Extra income
# ATSI
labinc_atsi <- make_group_var_year(data %>% filter(emp_pct>50),"labinc","atsi","ATSI","new_weight")
hours_atsi <- make_group_var_year(data %>% filter(emp_pct>50),"hours","atsi","ATSI","new_weight")


#=====================================================================
# NILF SPELL (start date) incidence by cuts

# Weighted by responding person weight hhwtrp
# Weight sum should be 15.0 million in wave 1, but is short even in raw data




#=====================================================================
# POOLED across all years, same as bove but not grouped by year


# Education
all_unemp_pct_educ <- make_group_var_pool(data,"unemp_pct","educ","Education","new_weight")

# Sex
all_unemp_pct_sex <- make_group_var_pool(data,"unemp_pct","sex","Gender","new_weight")

# ATSI
all_unemp_pct_atsi <- make_group_var_pool(data,"unemp_pct","atsi","ATSI","new_weight")

# Age
all_unemp_pct_age <- make_group_var_pool(data,"unemp_pct","age_group","Age","new_weight")

# Wealth
all_unemp_pct_networth <- make_group_var_pool(data,"unemp_pct","networth_ter","Net worth","new_weight")

# Lab income - super endogenous
#all_unemp_pct_labinc <- make_group_var_pool(data,"unemp_pct","labinc_ter","Labour income","new_weight")

# NONLab income
all_unemp_pct_nonlabinc <- make_group_var_pool(data,"unemp_pct","nonlabinc_ter","Non-labour income","new_weight")

# Wage
all_unemp_pct_wage <- make_group_var_pool(data,"unemp_pct","wage_ter","Wage","new_weight")

# Industry (modal)
all_unemp_pct_industry <- make_group_var_pool(data,"unemp_pct","industry_broad_mode","Broad industry","new_weight")

# Occupation (modal)
all_unemp_pct_occupation <- make_group_var_pool(data,"unemp_pct","occupation_broad_mode","Broad occupation","new_weight")


#=====================================================================
# Unemployment SPELL (end date) incidence by cuts


#=====================================================================
# HOURS

#=====================================================================
# Underemployment



#=====================================================================
# Viz - Unemployment PCT POOLED

# Merge all and add national urate back in
gnames <- ls(pattern="all_unem")
vizdata <- reduce(mget(gnames),
                  add_row) %>%
  filter(cat != "ATSI") %>%
  mutate(facet = factor(cat, levels = c("Gender",
                                        "ATSI",
                                        "Education",
                                        "Age",
                                        "Net worth",
                                        "Labour income",
                                        "Non-labour income",
                                        "Wage",
                                        "Broad industry",
                                        "Broad occupation"), ordered=T)) %>%
  group_by(facet) %>%
  # Ordering
  arrange(unemp_pct, .by_group = T) %>%
  mutate(order = 1:n()) %>%
  ungroup()


# Set colour key
vizdata <- vizdata %>%
  mutate(col = case_when(group == "University" ~ "1",
                         group == "Diploma" ~ "2",
                         group == "High school" ~ "3",
                         group == "Female" ~ "1",
                         group == "Male" ~ "2",
                         group == "Non-ATSI" ~ "1",
                         group == "ATSI" ~ "2",
                         group == "55-64" ~ "1",
                         group == "35-54" ~ "2",
                         group == "18-34" ~ "3",
                         group == "High" ~ "1",
                         group == "Mid" ~ "2",
                         group == "Low" ~ "3",
                         group == "Business services" ~ "1",
                         group == "Household services" ~ "2",
                         group == "Production and amenities" ~ "3",
                         group == "Trade and logistics" ~ "4",
                         group == "Non-routine cognitive" ~ "1",
                         group == "Routine cognitive" ~ "2",
                         group == "Non-routine manual" ~ "3",
                         group == "Routine manual" ~ "4",
                         ))

viz_unemp_all <- vizdata %>%
  filter(!is.na(group)) %>%
  filter(cat != "Non-labour income") %>%
  ggplot(aes(x = facet, y = unemp_pct, group = order, fill = col)) +
  geom_col(position = position_dodge2(width = 0.9, preserve = "single")) +
  coord_flip() +
  grattan_fill_manual(length(na.omit(unique(vizdata$col)))) +
  grattan_colour_manual(length(na.omit(unique(vizdata$col)))) +
  grattan_y_continuous(name = "Unemployment rate",
                       labels = function(x) paste0(x, "%"), limits = c(0,20)) +
  theme_grattan(flipped = TRUE) +
  grattan_label(aes(label = group, colour = col),
                position = position_dodge(width = 1),  # position dodge with width 1
                hjust = -0.1) +
  labs(title = "The most disadvantaged groups have higher unemployment rates",
       subtitle = "Average unemployment rate, population weighted",
       caption = paste0("Notes: Average share of time spent in unemployment (derived from employment calendars) across all HILDA waves 2001 to 2020. Weighted by the cross-sectional responding person weights. ",
                        "Sample restricted to people aged 18-64 and not retired. ",
                        "Source: Grattan analysis of HILDA Release 20.0") )

viz_unemp_all




#=====================================================================
# Viz - ATSI time series

vizdata <- unemp_pct_atsi %>%
  select(-cat) %>%
  #left_join(maxspell_unemp_atsi) %>%
  #select(-cat) %>%
  left_join(hours_atsi) %>%
  select(-cat) %>%
  left_join(labinc_atsi) %>%
  select(-cat) %>%
  pivot_longer(-c("year","group")) %>%
  mutate(group = case_when(group == "ATSI" ~ "Indigenous",
                           group == "Non-ATSI" ~ "Non-Indigenous")) %>%
  mutate(measure = case_when(name == "unemp_pct" ~ "Unemployment rate",
                             name == "labinc" ~ "Average annual labour income",
                             name == "hours" ~ "Hours usually worked per week",
                             name == "maxspell_unemp_end" ~ "Average spell length, months")) %>%
  mutate(facet = factor(measure, levels = c("Unemployment rate",
                                            "Hours usually worked per week",
                                            "Average annual labour income",
                                        "Average spell length, months"), ordered=T)) %>%
  group_by(facet) %>%
  mutate(col = as.factor(as.integer(factor(group)))) %>%
  ungroup()

# Labeller
labelmaker <- function(x) {
  ifelse(x > 100,
         paste0("$",format(round(x, 0), nsmall=0, big.mark=",")), paste0(x, "%"))
}

viz_unemp_atsi <- vizdata %>%
  filter(!is.na(group)) %>%
  ggplot(aes(x = year, y = value, col = group)) +
  geom_line() +
  scale_colour_manual(values = c(grattan_red, grattan_orange)) +
  grattan_y_continuous(labels = labelmaker, expand_bottom = 0.02) +
  theme_grattan() +
  theme(axis.title = element_blank()) +
  facet_wrap(vars(facet), nrow=3, scales = "free_y") +
  grattan_label(data = ~group_by(., group) %>% filter(year == 2006),
                aes(label = group),
                nudge_x = 1,
                hjust = 0) +
  labs(title = "Indigenous Australians face substantially worse labour market outcomes",
       #subtitle = "Average share of year in unemployment, population weighted",
       caption = paste0("Notes: Weighted by the cross-sectional responding person weights. Sample restricted to people aged 18-64 and not retired. ",
                        "Hours worked and labour income are the average of those employed for more than half of the financial year. ",
                        "Source: Grattan analysis of HILDA Release 20.0") )

viz_unemp_atsi






#=====================================================================
# Viz - output
