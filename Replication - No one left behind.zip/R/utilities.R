#==============================================================
# Utility function for R
# Alex Ballantyne (code derived from Will Mackey, Lachie Fox)
# 1 April 2022
#==============================================================




#-----------------------------------
# Function for creating quantile dummies (because quantcut() broke with NAs)
makequants <- function(DATA,group,varlist,probs) {
  ## DATA is data.frame
  ## group is char for group_by subsetting
  ## varlist is char vector of variable names to make quants for
  ## probs is vector of quantile probabilites 0-1

  # Make quantile breaks
  for (var in varlist) {
    for (i in 1:length(probs)) {
      DATA <- DATA %>%
        group_by(get(group)) %>%
        mutate("cut_{i}_{var}" := quantile(get(var),probs=probs[i],na.rm=TRUE) )
    }
  }

  # Ungroup
  DATA <- DATA %>%
    ungroup()

  # Make factors
  for (var in varlist) {
    for (i in 1:length(probs)) {
      if (i==1) { # First cut
        DATA <- DATA %>%
          mutate("quant_{var}" := if_else( get(var) <= get(paste0("cut_",i,"_",var)),
                                           as.integer(i),
                                           NA_integer_) )
      } else { # Between cuts
        DATA <- DATA %>%
          mutate("quant_{var}" := case_when( !is.na(get(paste0("quant_",var))) ~ get(paste0("quant_",var)),
                                             get(var) <= get(paste0("cut_",i,"_",var)) ~ as.integer(i),
                                             TRUE ~ NA_integer_) )
      }
      if (i==length(probs)) { # Final cut
        DATA <- DATA %>%
          mutate("quant_{var}" := if_else( get(var) > get(paste0("cut_",i,"_",var)),
                                           as.integer(i+1),
                                           get(paste0("quant_",var)) ) )
      }
    }
  }

  # Clean up
  DATA <- DATA %>%
    select( -starts_with(c("cut_")) )

  return(DATA)
}
#-----------------------------------

#-----------------------------------
# Function for cleaning quantile dummies over panel units - makes quantile constant within a panel unit and rebalances overall shares
cleanquants <- function(DATA,group,varlist,namelist,suffix) {
  ## DATA is data.frame
  ## group is panel unit to average over
  ## varlist is char vector of variable names to clean quants for
  ## namelist is char vector of labels for each quant, must be at least as long as number of quants
  ## suffix is char vector to append to all variable names

  # Convert to average quantile
  for (var in varlist) {
    DATA <- DATA %>%
      group_by(get(group)) %>%
      mutate("{var}_{suffix}" := mean(get(paste0("quant_",var)),na.rm=TRUE) ) %>%
      ungroup() %>%
      # Even out terciles so even mass
      mutate("{var}_{suffix}" := quantcut(get(paste0(var,"_",suffix)),length(p)+1,labels=FALSE) ) %>%
      # Rename terciles
      mutate("{var}_{suffix}" := case_when(get(paste0(var,"_",suffix))==1 ~ paste0(namelist[1]),
                                      get(paste0(var,"_",suffix))==2 ~ paste0(namelist[2]),
                                      get(paste0(var,"_",suffix))==3 ~ paste0(namelist[3]),
                                      get(paste0(var,"_",suffix))==4 ~ paste0(namelist[4]),
                                      get(paste0(var,"_",suffix))==5 ~ paste0(namelist[5]),
                                      get(paste0(var,"_",suffix))==6 ~ paste0(namelist[6]),
                                      get(paste0(var,"_",suffix))==7 ~ paste0(namelist[7]),
                                      get(paste0(var,"_",suffix))==8 ~ paste0(namelist[8]),
                                      get(paste0(var,"_",suffix))==9 ~ paste0(namelist[9]),
                                      get(paste0(var,"_",suffix))==10 ~ paste0(namelist[10]),
                                      get(paste0(var,"_",suffix))==11 ~ paste0(namelist[11]),
                                      get(paste0(var,"_",suffix))==12 ~ paste0(namelist[12]),
                                      get(paste0(var,"_",suffix))==13 ~ paste0(namelist[13]),
                                      get(paste0(var,"_",suffix))==14 ~ paste0(namelist[14]),
                                      get(paste0(var,"_",suffix))==15 ~ paste0(namelist[15]),
                                      get(paste0(var,"_",suffix))==16 ~ paste0(namelist[16]),
                                      get(paste0(var,"_",suffix))==17 ~ paste0(namelist[17]),
                                      get(paste0(var,"_",suffix))==18 ~ paste0(namelist[18]),
                                      get(paste0(var,"_",suffix))==19 ~ paste0(namelist[19]),
                                      get(paste0(var,"_",suffix))==20 ~ paste0(namelist[20]),) )
  }

  return(DATA)
}
#-----------------------------------


#-----------------------------------
# Function for making panel lead/lags
panelleadlags <- function(DATA,panel,delta,leads,lags,varlist) {
  ## DATA is data.frame
  ## panel is panel identifiers for panel()
  ## delta is time step for panel()
  ## leads is numeric vector of leads to make
  ## lags is numeric vector of lags to make
  ## varlist is char vector of variables in DATA


  # Panel data manipulation (lead/lag)
  gc()
  pdata <- panel(as.data.table(DATA), panel.id=panel, time.step=delta )

  # Loop over variables
  for (var in varlist) {
    # Loop over leads
    for (i in leads) {
      pdata[ ,paste0("f",i,"_",var) := fixest::f(get(var), lead=i)]
    }
    # Loop over lags
    for (j in lags) {
      pdata[ ,paste0("l",j,"_",var) := fixest::l(get(var), lag=j)]
    }
  }

  # make tibble and return
  DATA <- as_tibble(pdata)
  # Custom for HILDA
  DATA = relocate(DATA,xwaveid,year)
  return(DATA)
}
#-----------------------------------


#-----------------------------------
# Function for creating marginal effects @ average
# Somewhat specific to the HILDA_cyclical_unemp regression
margeffsatavg <- function(levels,reg,group,design_matrix_avg,design_matrix_shock_avg) {
  ## spells is from levels(spells[[group]])
  ## reg is the fixest model object
  ## group is char for group of factor variable
  ## shock is the size of the unemployment shock in ppt


    # Get levels, base and design
    base <- levels[1]
    ngroups <- length(levels)
    var_ints <- rep(paste0("urate:factor\\(",group,"\\)"),ngroups)
    marg <- rep(NA,ngroups)

    # Find which variables do what
    which_age <- unlist(gregexpr(":age",names(reg$coefficients)))>0
    which_levels <- !unlist(gregexpr("urate",names(reg$coefficients)))>0
    which_allints <- !which_age & !which_levels
    which_group <- unlist(gregexpr(group,names(reg$coefficients)))>0
    which_groupints <- which_group & which_allints

    # Set base to zero
    marg_base <- coefs*design_matrix_avg*(!which_group)
    marg_base_shock <- coefs*design_matrix_shock_avg*(!which_group)

    # Make base marg (standard predictions don't give what you would expect due to fixed effects)
    base <- sum(marg_base_shock)-sum(marg_base)

    # Loop over group values
    for (i in 1:ngroups) {
      # Make variable name
      var_ints[i] = paste0(var_ints[i],levels[i])
      # Check if exists in reg
      if (sum(unlist(gregexpr(var_ints[i],names(reg$coefficients)))*1>0)) {
        # Marginal effect for other groups is base group plus coefficient
        marg[i] <- reg$coefficients[gsub("\\\\","",var_ints[i])] + base
      } else {
        # Assume it is the base
        marg[i] <- base
      }
    }

    # Name it
    names(marg) <- gsub("\\\\","",var_ints)

  return(marg)
}
#-----------------------------------




#-----------------------------------
# functions to help with the legend/labels: ------------------------------------
# Courtesy of Will mackey (like all fine things)
gtext <- function(text, colour, bold = TRUE, .collapse = ", ") {
  if (bold)  ret <- glue("<b style='color:{colour}'>{text}</b>")
  if (!bold) ret <- glue("<span style='color:{colour}'>{text}</span>")
  if (!is_null(.collapse)) ret <- paste(ret, collapse = .collapse)
  return(ret)
}

gtext_legend <- function(named_vector, collapse = ", ", prefix = "") {
  glue(prefix, gtext(names(named_vector), named_vector, .collapse = collapse))
}


geom_gtext_legend <- function(vec = NULL,
                              position_x = 0,
                              position_y = 0,
                              collapse = "  ",
                              font_size = 18,
                              hjust = 0,
                              prefix = "",
                              ...) {

  df <- tibble(
    lab = gtext_legend(vec, collapse = collapse, prefix = prefix),
    x = position_x,
    y = position_y
  )

  geom_richtext(data = df,
                aes(label = lab, x = x, y = y),
                inherit.aes = FALSE,
                size = font_size/.pt, hjust = hjust, label.color = NA,
                ...)
}





