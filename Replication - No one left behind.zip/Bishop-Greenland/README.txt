To produce the local labour market data to take to R, first download the replication files for Bishop & Greenland 2021.
https://www.rba.gov.au/publications/rdp/2021/2021-09.html

Run all their code, then run the provided file "99_ABdataforR.do"
